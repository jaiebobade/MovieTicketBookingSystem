import React, { useState, useEffect } from 'react';
import axios from 'axios';


function TicketDetails() {
  const [ticketDetails, setTicketDetails] = useState([]);

  useEffect(() => {
    axios.get('your-api-endpoint')
      .then(response => {
        setTicketDetails(response.data);
      })
      .catch(error => {
        console.error('Error fetching ticket details:', error);
      });
  }, []);

  //Rest of the component code
//}

return (
//<tbody>
<tbody>
  {TicketDetails.map(ticket => (
    <tr key={ticket.booking_id}>
      <td>{ticket.booking_id}</td>
      <td>{ticticketket.user_name}</td>
      <td>{ticket.movie_name}</td>
      <td>{ticket.screen_name}</td>
      <td>{`${ticket.seat_row}-${ticket.seat_number}`}</td>
      <td>{ticket.show_date}</td>
      <td>{ticket.start_time}</td>
      <td>{ticket.total_tickets}</td>
      <td>{ticket.total_amount}</td>
    </tr> 
  ))}
  
</tbody>

);
}

//export default TicketDetails;
export default TicketDetails;

