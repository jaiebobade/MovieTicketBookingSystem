import React from "react";
import { useDispatch } from "react-redux";
import { useNavigate } from "react-router-dom";
import { adminActions } from "../../store";
import AuthForm from "./AuthForm";

const Admin = () => {
  const navigate = useNavigate();
  const dispatch = useDispatch();
  
  const onSubmit = () => {
    // Simulate successful admin login
    const fakeAdminData = {
      id: "admin1",
      token: "dummy-token",
    };

    dispatch(adminActions.login());
    localStorage.setItem("adminId", fakeAdminData.id);
    localStorage.setItem("token", fakeAdminData.token);
    
    navigate("/");
  };

  return (
    <div>
      <AuthForm onSubmit={onSubmit} isAdmin={true} />
    </div>
  );
};

export default Admin;
