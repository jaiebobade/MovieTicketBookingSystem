import { Button, FormLabel, TextField, Typography } from "@mui/material";
import { Box } from "@mui/system";
import React, { Fragment, useEffect, useState } from "react";
import { FormControl, InputLabel, Select, MenuItem } from "@mui/material";

import { Link, useParams } from "react-router-dom";
import {
  getTheatresForCity,
  getScreensForTheatre,
  getShowsForMovie,
  getMovieById
} from "../../api-helpers/api-helpers";
import { Button as MuiButton } from "@mui/material"; // Keep this import


const Booking = ({ movie }) => {
  
  const [theatres, setTheatres] = useState([]);
  const [screens, setScreens] = useState([]);
  const [shows, setShows] = useState([]);
  const [amount, setAmount] = useState(0);

  const [selectedCity, setSelectedCity] = useState('');
  const [selectedTheatre, setSelectedTheatre] = useState('');
  const [selectedScreen, setSelectedScreen] = useState('');
  const [selectedSeats, setSelectedSeats] = useState([]);
  const [seatStatus, setSeatStatus] = useState(Array.from({ length: 20 }, () => false));
  const [selectedShow, setSelectedShow] = useState('');
  const { id } = useParams();

  useEffect(() => {
    async function fetchMovie() {
      try {
        const movieData = await getMovieById(id);
        setMovie(movieData);
      } catch (error) {
        // Handle error
      }
    }

    fetchMovie();
  }, [id]);

  useEffect(() => {
    if (selectedCity) {
      getTheatresForCity(selectedCity).then((data) => {
        if (data) {
          setTheatres(data);
        }
      });
    }
  }, [selectedCity]);

  // useEffect(() => {
  //   if (selectedTheatre) {
  //     getScreensForTheatre(selectedTheatre).then((data) => {
  //       if (data) {
  //         setScreens(data);
  //       }
  //     });
  //   }
  // }, [selectedTheatre]);













  useEffect(() => {
    if (selectedScreen) {
      getShowsForMovie(selectedScreen).then((data) => {
        if (data) {
          setShows(data);
        }
      });
    }
  }, [selectedScreen]);

 
  const handleCheckboxChange = (seatNumber) => {
    const updatedSelectedSeats = selectedSeats.includes(seatNumber)
      ? selectedSeats.filter((seat) => seat !== seatNumber)
      : [...selectedSeats, seatNumber];
  
    setSelectedSeats(updatedSelectedSeats);
  };
  
  const calculateAmount = () => {
    const seatCount = selectedSeats.length;
    let amount = 0;
  
    selectedSeats.forEach((seatNumber) => {
      if (seatNumber >= 1 && seatNumber <= 5) {
        amount += 100;
      } else if (seatNumber >= 6 && seatNumber <= 10) {
        amount += 150;
      } else if (seatNumber >= 11 && seatNumber <= 15) {
        amount += 200;
      } else if (seatNumber >= 16 && seatNumber <= 20) {
        amount += 250;
      }
    });
  
    return amount;
  };

  const handleChange = (e) => {
    setInputs((prevState) => ({
      ...prevState,
      [e.target.name]: e.target.value,
    }));
  };
  const handleSubmit = (e) => {
    e.preventDefault();
    console.log(inputs);
    newBooking({ ...inputs, movie: movie._id })
      .then((res) => console.log(res))
      .catch((err) => console.log(err));
  };
  return (
    <div style={{ display: 'flex', flexDirection: 'row', height: '100%' }}>
      {movie && (
        <div style={{ flex: '30%', padding: '20px' }}>
          <img
            width="80%"
            height={"300px"}
            src={movie.image}
            alt={movie.title}
          />
          <Typography
            padding={3}
            fontFamily="fantasy"
            variant="h4"
            textAlign={"center"}
          >
            Book Tickets Of Movie: {movie.title}
          </Typography>
          <div style={{ marginTop: '20px', textAlign: 'center' }}>
            <Typography>{movie.description}</Typography>
            <Typography>
              Release Date: {new Date(movie.release_date).toDateString()}
            </Typography>
            <Typography>Duration: {movie.duration}</Typography>
            <Typography>Genre: {movie.genre}</Typography>
            <Typography>Director: {movie.director}</Typography>
            <Typography>Cast: {movie.cast.join(', ')}</Typography>
          </div>
        </div>
      )}
      {/* Booking form */}
   <div style={{ flex: '70%', padding: '20px' }}>
  <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center' }}>
    <div style={{ marginBottom: '20px' }}>
    <Typography variant="h6">Select City:</Typography>

      <FormControl>
        <Select
          value={selectedCity}
          onChange={(e) => setSelectedCity(e.target.value)}
        >
          <MenuItem value="Pune">Pune</MenuItem>
          <MenuItem value="Mumbai">Mumbai</MenuItem>
          <MenuItem value="Kolhapur">Kolhapur</MenuItem>
        </Select>
      </FormControl>



      {/* <Typography variant="h6">Select Theatre:</Typography>
      <FormControl>
  <Select
    value={selectedTheatre}
    onChange={(e) => setSelectedTheatre(e.target.value)}
  >
    {theatres.map((theatre) => (
      <MenuItem key={theatre.id} value={theatre.id}>
        {theatre.name}
      </MenuItem>
    ))}
  </Select>
</FormControl> */}



<Typography variant="h6">Select Theatre:</Typography>
<FormControl>
  <Select
    value={selectedTheatre}
    onChange={(e) => setSelectedTheatre(e.target.value)}
  >
    {selectedCity === 'Pune' && [
      <MenuItem key="pvr" value="PVR">PVR</MenuItem>,
      <MenuItem key="pvrshow" value="PVR SHOW">PVR SHOW</MenuItem>,
      <MenuItem key="rahul" value="Rahul 70mm">Rahul 70mm</MenuItem>
    ]}

    {selectedCity === 'Mumbai' && [
      <MenuItem key="alka" value="Alka talkies">Alka talkies</MenuItem>,
      <MenuItem key="pavillion" value="Pavillion">Pavillion</MenuItem>,
      <MenuItem key="sonam" value="Sonam">Sonam</MenuItem>
    ]}

    {selectedCity === 'Kolhapur' && [
      <MenuItem key="pvrdyp" value="PVR DYP City Mall">PVR DYP City Mall</MenuItem>,
      <MenuItem key="inoxreliance" value="INOX Reliance Mall">INOX Reliance Mall</MenuItem>,
      <MenuItem key="citypride" value="City Pride Multiplex">City Pride Multiplex</MenuItem>
    ]}
  </Select>
</FormControl>



<Typography variant="h6">Select Screen:</Typography>
      <FormControl>
        <Select
          value={selectedScreen}
          onChange={(e) => setSelectedScreen(e.target.value)}
        >
          <MenuItem value="Screen 1">Screen 1</MenuItem>
          <MenuItem value="Screen 2">Screen 2</MenuItem>
        </Select>
      </FormControl>






{/* <Typography variant="h6">Select Screen:</Typography>

      <FormControl>
        <Select
          value={selectedScreen}
          onChange={(e) => setSelectedScreen(e.target.value)}
        >
          {screens.map((screen) => (
            <MenuItem key={screen.id} value={screen.id}>
              {screen.name}
            </MenuItem>
          ))}
        </Select>
      </FormControl> */}




      <Typography variant="h6">Select Date & Time:</Typography>

          <FormControl>
  <Select
    value={selectedShow}
    onChange={(e) => setSelectedShow(e.target.value)}
  >
    {shows.map((show) => (
      <MenuItem key={show.id} value={show.id}>
        {show.dateTime} {/* Change this to your actual show time */}
      </MenuItem>
    ))}
  </Select>
</FormControl>
            </div>
            <div style={{ display: 'flex', flexDirection: 'column' }}>
  {Array.from({ length: 20 }, (_, index) => {
    let seatPrice = 0;
    if (index < 5) {
      seatPrice = 100;
    } else if (index < 10) {
      seatPrice = 150;
    } else if (index < 15) {
      seatPrice = 200;
    } else {
      seatPrice = 250;
    }

    return (
      <div key={index} style={{ margin: '5px' }}>
        <input
          type="checkbox"
          checked={selectedSeats.includes(index)}
          onChange={() => handleCheckboxChange(index)}
        />
        Seat {index + 1} ({seatPrice} Rs)
      </div>
    );
  })}
</div>
<div style={{ marginTop: '20px' }}>
  <TextField
    label="Amount"
    value={calculateAmount()}
    disabled
  />
</div>
<Link to="/ticket" style={{ textDecoration: 'none', marginTop: '20px' }}>
          <MuiButton variant="contained" color="primary">
            Continue
          </MuiButton>
        </Link>
        </div>
      </div>
    </div>
  );
      }

export default Booking;
