import React, { useState } from 'react';
import { useParams } from 'react-router-dom';
import { Button, Typography, TextField } from '@mui/material';
import { deleteMovie } from '../../api-helpers/api-helpers';

const DeleteMovie = () => {
  const { movieId } = useParams();
  const [deleteMessage, setDeleteMessage] = useState('');

  const handleDelete = async () => {
    const response = await deleteMovie(movieId);
    if (response) {
      setDeleteMessage(response.message || 'Movie deleted successfully');
    } else {
      setDeleteMessage('Error deleting movie');
    }
  };

  return (
    <div>
      <Typography variant="h5" gutterBottom>
        Delete Movie
      </Typography>
    
      <TextField
            value={inputs.title}
            onChange={handleChange}
            name="title"
            variant="standard"
            margin="normal"
          />
    
      <Button variant="contained" color="error" onClick={handleDelete}>
        Delete
      </Button>
      <Typography variant="body1" color="error" style={{ marginTop: '10px' }}>
        {deleteMessage}
      </Typography>
    </div>
  );
};

export default DeleteMovie;
