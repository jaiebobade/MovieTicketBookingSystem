import React, { useState } from 'react';
import { TextField, Button, Box, Typography } from '@mui/material';
import { updateMovie } from '../../api-helpers/api-helpers';

const UpdateMovie = () => {
  const [movieId, setMovieId] = useState('');
  const [title, setTitle] = useState('');
  const [director, setDirector] = useState('');
  const [releaseDate, setReleaseDate] = useState('');

  const handleUpdate = async () => {
    if (!movieId || !title || !director || !releaseDate) {
      console.log('Please fill in all fields');
      return;
    }

    const updatedData = {
      title,
      director,
      release_date: releaseDate,
    };

    const res = await updateMovie(movieId, updatedData);

    if (res) {
      console.log('Movie updated successfully:', res);
      // Clear form fields after successful update
      setMovieId('');
      setTitle('');
      setDirector('');
      setReleaseDate('');
    } else {
      console.log('Failed to update movie');
    }
  };

  return (
    <Box>
      <Typography variant="h5" gutterBottom>
        Update Movie
      </Typography>
      <TextField
        label="Movie ID"
        value={movieId}
        onChange={(e) => setMovieId(e.target.value)}
        fullWidth
        margin="normal"
      />
      <TextField
        label="Title"
        value={title}
        onChange={(e) => setTitle(e.target.value)}
        fullWidth
        margin="normal"
      />
      <TextField
        label="Director"
        value={director}
        onChange={(e) => setDirector(e.target.value)}
        fullWidth
        margin="normal"
      />
      <TextField
        label="Release Date"
        type="date"
        value={releaseDate}
        onChange={(e) => setReleaseDate(e.target.value)}
        fullWidth
        margin="normal"
      />
      <Button variant="contained" color="primary" onClick={handleUpdate}>
        Update
      </Button>
    </Box>
  );
};

export default UpdateMovie;
