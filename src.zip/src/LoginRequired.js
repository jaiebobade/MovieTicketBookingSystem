import React from 'react';

const LoginRequired = () => {
  return (
    <div>
      <p>Please log in to access this content.</p>
    </div>
  );
};

export default LoginRequired;
