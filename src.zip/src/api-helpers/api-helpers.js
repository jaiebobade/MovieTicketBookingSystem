// import axios from "axios";
// const API_BASE_URL = 'http://localhost:4000'; 


// export const getAllMovies = async () => {
//     try {
//       const response = await axios.get(`${API_BASE_URL}/movie`);
//       return response.data;
//       console.log(response.data);
//     } catch (error) {
//       // console.error('Error fetching movies:', error);
//       return null;
//     }
//   };

  
//   export const getMovieById = async (movieId) => {
//     try {
//       const response = await axios.get(`${API_BASE_URL}/movies/${movieId}`);
//       return response.data;
//     } catch (error) {
//       console.error("Error retrieving movie: ", error);
//       throw error;
//     }
//   };

//   export const getTheatresForCity = async (city) => {
//     try {
//       const response = await axios.get(`${API_BASE_URL}/cityName/${city}`);
//       return response.data;
//     } catch (error) {
//       console.error('Error fetching theatres:', error);
//       return null;
//     }
//   };
  
//   export const getScreensForTheatre = async (theatreId) => {
//     try {
//       const response = await axios.get(`${API_BASE_URL}/theatre/${theatreId}`);
//       return response.data;
//     } catch (error) {
//       console.error('Error fetching screens:', error);
//       return null;
//     }
//   };
  
//   export const getShowsForMovie = async (movieId) => {
//     try {
//       const response = await axios.get(`${API_BASE_URL}/movies/${movieId}`);
//       return response.data;
//     } catch (error) {
//       console.error('Error fetching shows:', error);
//       return null;
//     }
//   };
//   export const sendUserAuthRequest = async (data, signup) => {
//     if (signup) {
//       const res = await axios.post(`/register`, {
//         username: data.username,
//         email: data.email,
//         password: data.password,
//         name: data.name,
//         phone: data.phone,
//         address: data.address,
//       }).catch((err) => console.log(err));
  
//       if (res && (res.status === 200 || res.status === 201)) {
//         const resData = res.data;
//         return resData;
//       } else {
//         console.log("Unexpected Error Occurred");
//       }
//     }
//   };
  

//   export const getMovieDetails = async (id) => {
//     const res = await axios.get(`/movie/${id}`).catch((err) => console.log(err));
//     if (res.status !== 200) {
//       return console.log("Unexpected Error");
//     }
//     const resData = await res.data;
//     return resData;
//   };
  
//   export const newBooking = async (data) => {
//     const res = await axios
//       .post("/booking", {
//         movie: data.movie,
//         seatNumber: data.seatNumber,
//         date: data.date,
//         user: localStorage.getItem("userId"),
//       })
//       .catch((err) => console.log(err));
  
//     if (res.status !== 201) {
//       return console.log("Unexpected Error");
//     }
//     const resData = await res.data;
//     return resData;
//   };
  
//   export const getUserBooking = async () => {
//     const id = localStorage.getItem("userId");
//     const res = await axios
//       .get(`/user/bookings/${id}`)
//       .catch((err) => console.log(err));
  
//     if (res.status !== 200) {
//       return console.log("Unexpected Error");
//     }
//     const resData = await res.data;
//     return resData;
//   };
  
//   export const deleteBooking = async (id) => {
//     const res = await axios
//       .delete(`/booking/${id}`)
//       .catch((err) => console.log(err));
  
//     if (res.status !== 200) {
//       return console.log("Unepxected Error");
//     }
  
//     const resData = await res.data;
//     return resData;
//   };
  
//   export const getUserDetails = async () => {
//     const id = localStorage.getItem("userId");
//     const res = await axios.get(`/user/${id}`).catch((err) => console.log(err));
//     if (res.status !== 200) {
//       return console.log("Unexpected Error");
//     }
//     const resData = await res.data;
//     return resData;
//   };
  
//   export const addMovie = async (data) => {
//     try {
//       const res = await axios.post(
//         `${API_BASE_URL}/movie`, // Add the base URL here
//         {
//           title: data.title,
//           description: data.description,
//           release_date: data.releaseDate,
//           duration: data.duration,
//           genre: data.genre,
//           director: data.director,
//           cast: data.actors,
//           image: data.image,
//         }
//       );
  
//       if (res.status !== 200) {
//         return console.log("Unexpected Error Occurred");
//       }
  
//       const resData = await res.data;
//       return resData;
//     } catch (error) {
//       console.error(error);
//       return null;
//     }
//   };
  
//   export const updateMovie = async (movieId, updatedData) => {
//     try {
//       const res = await axios.put(`${API_BASE_URL}/admin/movies/${movieId}`, updatedData);
  
//       if (res.status !== 200) {
//         console.log('Unexpected Error Occurred');
//         return null;
//       }
  
//       const resData = await res.data;
//       return resData;
//     } catch (error) {
//       console.error(error);
//       return null;
//     }
//   };

//   export const deleteMovie = async (movieId) => {
//     try {
//       const res = await axios.delete(`${API_BASE_URL}/admin/movies/${movieId}`);
  
//       if (res.status !== 200) {
//         console.log('Unexpected Error Occurred');
//         return null;
//       }
  
//       const resData = await res.data;
//       return resData;
//     } catch (error) {
//       console.error(error);
//       return null;
//     }
//   };
  
  
 
import axios from "axios";
const API_BASE_URL = 'http://localhost:4000'; 


export const getAllMovies = async () => {
    try {
      const response = await axios.get(`${API_BASE_URL}/movie`);
      return response.data;
      console.log(response.data);
    } catch (error) {
      // console.error('Error fetching movies:', error);
      return null;
    }
  };







  
  export const getMovieById = async (movieId) => {
    try {
      const response = await axios.get(`${API_BASE_URL}/movies/${movieId}`);
      return response.data;
    } catch (error) {
      console.error("Error retrieving movie: ", error);
      throw error;
    }
  };

  export const getTheatresForCity = async (city) => {
    try {
      const response = await axios.get(`${API_BASE_URL}/cityName/${city}`);
      return response.data;
    } catch (error) {
      console.error('Error fetching theatres:', error);
      return null;
    }
  };
  
  export const getScreensForTheatre = async (theatreId) => {
    try {
      const response = await axios.get(`${API_BASE_URL}/theatre/${theatreId}`);
      return response.data;
    } catch (error) {
      console.error('Error fetching screens:', error);
      return null;
    }
  };
  
  export const getShowsForMovie = async (movieId) => {
    try {
      const response = await axios.get(`${API_BASE_URL}/movies/${movieId}`);
      return response.data;
    } catch (error) {
      console.error('Error fetching shows:', error);
      return null;
    }
  };
  export const sendUserAuthRequest = async (data, signup) => {
    if (signup) {
      const res = await axios.post(`/register`, {
        username: data.username,
        email: data.email,
        password: data.password,
        name: data.name,
        phone: data.phone,
        address: data.address,
      }).catch((err) => console.log(err));
  
      if (res && (res.status === 200 || res.status === 201)) {
        const resData = res.data;
        return resData;
      } else {
        console.log("Unexpected Error Occurred");
      }
    }
  };
  

  export const getMovieDetails = async (id) => {
    const res = await axios.get(`/movie/${id}`).catch((err) => console.log(err));
    if (res.status !== 200) {
      return console.log("Unexpected Error");
    }
    const resData = await res.data;
    return resData;
  };
  
  export const newBooking = async (data) => {
    const res = await axios
      .post("/booking", {
        movie: data.movie,
        seatNumber: data.seatNumber,
        date: data.date,
        user: localStorage.getItem("userId"),
      })
      .catch((err) => console.log(err));
  
    if (res.status !== 201) {
      return console.log("Unexpected Error");
    }
    const resData = await res.data;
    return resData;
  };
  
  export const getUserBooking = async () => {
    const id = localStorage.getItem("userId");
    const res = await axios
      .get(`/user/bookings/${id}`)
      .catch((err) => console.log(err));
  
    if (res.status !== 200) {
      return console.log("Unexpected Error");
    }
    const resData = await res.data;
    return resData;
  };
  
  export const deleteBooking = async (id) => {
    const res = await axios
      .delete(`/booking/${id}`)
      .catch((err) => console.log(err));
  
    if (res.status !== 200) {
      return console.log("Unepxected Error");
    }
  
    const resData = await res.data;
    return resData;
  };
  
  export const getUserDetails = async () => {
    const id = localStorage.getItem("userId");
    const res = await axios.get(`/user/${id}`).catch((err) => console.log(err));
    if (res.status !== 200) {
      return console.log("Unexpected Error");
    }
    const resData = await res.data;
    return resData;
  };
  
  export const addMovie = async (data) => {
    try {
      const res = await axios.post(
        `${API_BASE_URL}/movie`, // Add the base URL here
        {
          title: data.title,
          description: data.description,
          release_date: data.releaseDate,
          duration: data.duration,
          genre: data.genre,
          director: data.director,
          cast: data.actors,
          image: data.image,
        }
      );
  
      if (res.status !== 200) {
        return console.log("Unexpected Error Occurred");
      }
  
      const resData = await res.data;
      return resData;
    } catch (error) {
      console.error(error);
      return null;
    }
  };
  
  export const updateMovie = async (movieId, updatedData) => {
    try {
      const res = await axios.put(`${API_BASE_URL}/admin/movies/${movieId}`, updatedData);
  
      if (res.status !== 200) {
        console.log('Unexpected Error Occurred');
        return null;
      }
  
      const resData = await res.data;
      return resData;
    } catch (error) {
      console.error(error);
      return null;
    }
  };

  export const deleteMovie = async (movieId) => {
    try {
      const res = await axios.delete(`${API_BASE_URL}/admin/movies/${movieId}`);
  
      if (res.status !== 200) {
        console.log('Unexpected Error Occurred');
        return null;
      }
  
      const resData = await res.data;
      return resData;
    } catch (error) {
      console.error(error);
      return null;
    }
  };
  
  
 
  