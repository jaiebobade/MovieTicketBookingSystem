// SELECT
//   Movie.title AS movie_title,
//   Theatre.name AS theatre_name,
//   Screen.name AS screen_name,
//   `Show`.start_time AS show_start_time,
//   `Show`.end_time AS show_end_time
// FROM Movie
// JOIN `Show` ON Movie.id = `Show`.movie_id
// JOIN Screen ON `Show`.screen_id = Screen.id
// JOIN Theatre ON Screen.theatre_id = Theatre.id
// WHERE Movie.id = ?;


const express = require('express');
const router = express.Router();
const db = require('your-database-library'); // Replace with your actual database library

// GET /shows/:movieId - Get shows by movie ID
router.get('/:movieId', (req, res) => {
  const movieId = req.params.movieId;
  const query = `
    SELECT
      Movie.title AS movie_title,
      Theatre.name AS theatre_name,
      Screen.name AS screen_name,
      \`Show\`.start_time AS show_start_time,
      \`Show\`.end_time AS show_end_time
    FROM Movie
    JOIN \`Show\` ON Movie.id = \`Show\`.movie_id
    JOIN Screen ON \`Show\`.screen_id = Screen.id
    JOIN Theatre ON Screen.theatre_id = Theatre.id
    WHERE Movie.id = ?;
  `;

  db.query(query, [movieId], (err, results) => {
    if (err) {
      console.error('Error retrieving shows:', err);
      res.status(500).json({ error: 'Error retrieving shows' });
      return;
    }
    res.json(results);
  });
});






SELECT
  Booking.id AS booking_id,
  Movie.title AS movie_title,
  Theatre.name AS theatre_name,
  Screen.name AS screen_name,
  `Show`.start_time AS show_start_time,
  `Show`.end_time AS show_end_time,
  GROUP_CONCAT(Seats.row, Seats.seat_number ORDER BY Seats.id ASC) AS seat_numbers,
  Booking.total_tickets,
  Booking.total_amount
FROM Booking
JOIN User ON Booking.user_id = User.id
JOIN `Show` ON Booking.show_id = `Show`.id
JOIN Movie ON `Show`.movie_id = Movie.id
JOIN Screen ON `Show`.screen_id = Screen.id
JOIN Theatre ON Screen.theatre_id = Theatre.id
JOIN Tickets ON Booking.id = Tickets.booking_id
JOIN Seats ON Tickets.seat_id = Seats.id
WHERE User.id = ?;



const express = require('express');
const router = express.Router();
const db = require('your-database-library'); // Replace with your actual database library

// GET /shows/:userId - Get shows by user ID
router.get('/:userId', (req, res) => {
  const userId = req.params.userId;
  const query = `
    SELECT
      Booking.id AS booking_id,
      Movie.title AS movie_title,
      Theatre.name AS theatre_name,
      Screen.name AS screen_name,
      \`Show\`.start_time AS show_start_time,
      \`Show\`.end_time AS show_end_time,
      GROUP_CONCAT(Seats.row, Seats.seat_number ORDER BY Seats.id ASC) AS seat_numbers,
      Booking.total_tickets,
      Booking.total_amount
    FROM Booking
    JOIN User ON Booking.user_id = User.id
    JOIN \`Show\` ON Booking.show_id = \`Show\`.id
    JOIN Movie ON \`Show\`.movie_id = Movie.id
    JOIN Screen ON \`Show\`.screen_id = Screen.id
    JOIN Theatre ON Screen.theatre_id = Theatre.id
    JOIN Tickets ON Booking.id = Tickets.booking_id
    JOIN Seats ON Tickets.seat_id = Seats.id
    WHERE User.id = ?
    GROUP BY Booking.id;
  `;

  db.query(query, [userId], (err, results) => {
    if (err) {
      console.error('Error retrieving shows:', err);
      res.status(500).json({ error: 'Error retrieving shows' });
      return;
    }
    res.json(results);
  });
});

module.exports = router;
