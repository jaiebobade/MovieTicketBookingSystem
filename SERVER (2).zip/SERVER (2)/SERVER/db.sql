CREATE DATABASE db_Project


CREATE TABLE User (
    user_id INT PRIMARY KEY AUTO_INCREMENT,
    username VARCHAR(255) NOT NULL,
    password VARCHAR(255) NOT NULL,
    email VARCHAR(255) NOT NULL,
    name VARCHAR(255),
    phone VARCHAR(20),
    address VARCHAR(255)
);


CREATE TABLE Movie (
    movie_id INT PRIMARY KEY AUTO_INCREMENT,
    title VARCHAR(255) NOT NULL,
    description TEXT,
    release_date DATE,
    duration INT,
    genre VARCHAR(255),
    director VARCHAR(255),
    cast VARCHAR(255),
    image VARCHAR(255)
);

CREATE TABLE Theatre (
    theatre_id INT PRIMARY KEY AUTO_INCREMENT,4
    name VARCHAR(255) NOT NULL,
    address VARCHAR(255),
    city VARCHAR(255),
    state VARCHAR(255),
    country VARCHAR(255)
);



CREATE TABLE Screen (
    screen_id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(255) NOT NULL,
    capacity INT,
    theatre_id INT,
    FOREIGN KEY (theatre_id) REFERENCES Theatre(theatre_id)
);


CREATE TABLE Shows
 (    
    show_id INT PRIMARY KEY AUTO_INCREMENT,
    theatre_id INT,
    screen_id INT,
    movie_id INT,
    show_date DATE,
    start_time DATETIME,
    end_time DATETIME,
    FOREIGN KEY (screen_id) REFERENCES Screen (screen_id),
    FOREIGN KEY (movie_id) REFERENCES Movie (movie_id),
    FOREIGN KEY (theatre_id) REFERENCES Theatre (theatre_id)
);

CREATE TABLE Seats (
    seat_id INT PRIMARY KEY AUTO_INCREMENT,
    theatre_id INT,
    screen_id INT,
    seat_row VARCHAR(10),
    seat_number INT,
    seat_type VARCHAR(20),
    is_reserved BOOLEAN,
    price DECIMAL(10, 2),
    FOREIGN KEY (theatre_id) REFERENCES Theatre(theatre_id),
    FOREIGN KEY (screen_id) REFERENCES Screen(screen_id)
);


CREATE TABLE Booking (
    booking_id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT,
    screen_id INT,
    show_id INT,
    movie_id INT,
    seat_id INT, -- New column to track the booked seat
    booking_date DATE,
    total_tickets INT,
    total_amount DECIMAL(10, 2),
    FOREIGN KEY (user_id) REFERENCES User(user_id),
    FOREIGN KEY (screen_id) REFERENCES Screen(screen_id),
    FOREIGN KEY (show_id) REFERENCES Shows(show_id),
    FOREIGN KEY (movie_id) REFERENCES Movie(movie_id),
    FOREIGN KEY (seat_id) REFERENCES Seats(seat_id) -- Foreign key reference to the Seats table
);


CREATE TABLE Tickets (
    ticket_id INT PRIMARY KEY AUTO_INCREMENT,
    booking_id INT,
    price DECIMAL(10, 2),
    FOREIGN KEY (booking_id) REFERENCES Booking(booking_id)
);


CREATE TABLE Admin (
    admin_id INT PRIMARY KEY AUTO_INCREMENT,
    username VARCHAR(255) NOT NULL,
    password VARCHAR(255) NOT NULL
);







INSERT INTO Admin VALUES(1,"admin1@gmail.com","admin1");
INSERT INTO Admin VALUES(2,"admin2@gmail.com","admin2");
INSERT INTO Admin VALUES(3,"admin3@gmail.com","admin3");

--------------------------------------------------------------------------------------------------------

INSERT INTO User (username, password, email, name, phone, address)
VALUES ('john123', 'password123', 'john@example.com', 'John Doe', '1234567890', '123 Street, City');
INSERT INTO User (username, password, email, name, phone, address)
VALUES ('sanika', 'sanika123', 'sanikajadhav@gmail.com', 'Sanika Jadhav', '9876543210', 'Dahiwadi, Satara');
INSERT INTO User (username, password, email, name, phone, address)
VALUES ('abhishek', 'abhi123', 'abhi@example.com', 'Abhishek Jadhav', '9370405500', 'Dahwiadi, Satara');
INSERT INTO User (username, password, email, name, phone, address)
VALUES ('bharti', 'bharti123', 'bharti@example.com', 'Bharti Jadhav', '1234567809', 'ChandniChowk, Pune');
INSERT INTO User (username, password, email, name, phone, address)
VALUES ('pradeep', 'pradeep123', 'pradeep@example.com', 'Pradeep Jadhav', '1234567800', '1234 street, Mumbai');

---------------------------------------------------------------------------------------------------------

INSERT INTO Movie (title, description, release_date, duration, genre, director, cast, image)
VALUES ('', '', '', , '', '', '', '');

INSERT INTO Movie (title, description, release_date, duration, genre, director, cast, image)VALUES ('Salaam Venky', 'The film takes a balanced look at why euthanasia should be favoured or opposed. But the most beautiful parts are the relationship between the mother and son and the positive attitude that Venky lives with. ', '2023-02-09',136 , 'Feature film soundtrack', 'Revathi', 'Kajol, Vishal Jethwa', '1.jpg');

INSERT INTO Movie (title, description, release_date, duration, genre, director, cast, image)VALUES ('Fast X', 'The end of the road begins. The tenth film in Fast and furious saga, launches its final chapter.', '2023-05-12',141 , 'Action', 'Louis Leterrier', 'Vin Diesel,Michelle Rodriguez, Tyrese Gibson, Ludacris, John Cena, Nathalie Emmanuel, Jordana Brewster', '2.jpg');

INSERT INTO Movie (title, description, release_date, duration, genre, director, cast, image)VALUES ('Spiderman- No way home', 'Peter Parker s secret identity is revealed to the entire world. Desperate for help, Peter turns to Doctor Strange to make the world forget that he is Spider-Man. The spell goes horribly wrong and shatters the multiverse, bringing in monstrous villains that could destroy the world.', '2023-02-17',148 , 'Action', 'Jon Watts', 'Tom Holland, Zendaya', '3.jpg');

INSERT INTO Movie (title, description, release_date, duration, genre, director, cast, image)VALUES ('Freddy', 'This is a story about a dentist Dr.Freddy who gets rejected by everyone, and then how he fights for all the circumstances', '2022-12-02',124, 'Thriller', 'Shashanka Ghosh', 'Kartik Aryan, Alaya F', '4.jpg');

INSERT INTO Movie (title, description, release_date, duration, genre, director, cast, image) VALUES ('The Silent Witness', 'A thrilling courtroom drama revolving around a high-profile murder case and the enigmatic witness.', '2023-02-28', 128, 'Mystery, Thriller', 'Denis Villeneuve', 'Jake Gyllenhaal, Emma Stone', '5.jpg');

INSERT INTO Movie (title, description, release_date, duration, genre, director, cast, image) VALUES ('Love in Paris', 'A romantic comedy set in the picturesque streets of Paris, where love blossoms in unexpected ways.', '2023-02-14', 115, 'Romance, Comedy', 'Jean-Pierre Jeunet', 'Marion Cotillard, Omar Sy', '6.jpg');

INSERT INTO Movie (title, description, release_date, duration, genre, director, cast, image) VALUES ('The Last Samurai', 'An epic historical drama about a Western soldier who embraces the samurai culture in 19th-century Japan.', '2023-05-05', 175, 'Drama, Action', 'Edward Zwick', 'Tom Cruise, Ken Watanabe', '7.jpg');

INSERT INTO Movie (title, description, release_date, duration, genre, director, cast, image) VALUES ('The Enchanted Forest', 'A magical adventure of two siblings who stumble upon an enchanted forest and encounter fantastical creatures.', '2023-07-20', 98, 'Family, Fantasy', 'Joe Johnston', 'Emily Blunt, Finn Wolfhard', '8.jpg');


INSERT INTO Movie (title, description, release_date, duration, genre, director, cast, image) VALUES ('Dilwale Dulhania Le Jayenge', 'A timeless romantic tale of two young individuals who fall in love during a trip across Europe.', '2023-01-20', 189, 'Romance, Drama', 'Aditya Chopra', 'Shah Rukh Khan, Kajol', '9.jpg');

INSERT INTO Movie (title, description, release_date, duration, genre, director, cast, image) VALUES ('Kabhi Khushi Kabhie Gham', 'A multi-generational family drama that explores love, relationships, and the importance of family bonds.', '2023-02-14', 210, 'Drama, Romance', 'Karan Johar', 'Shah Rukh Khan, Kajol, Amitabh Bachchan', '10.jpg');

INSERT INTO Movie (title, description, release_date, duration, genre, director, cast, image) VALUES ('3 Idiots', 'A comedy-drama about the pursuit of passion and the importance of embracing individuality in the face of societal expectations.', '2023-02-25', 170, 'Comedy, Drama', 'Rajkumar Hirani', 'Aamir Khan, Kareena Kapoor Khan', '11.jpg');

INSERT INTO Movie (title, description, release_date, duration, genre, director, cast, image) VALUES ('Chennai Express', 'A romantic action-comedy about a man who falls in love with a woman while traveling on a chaotic train journey.', '2023-05-08', 141, 'Romance, Comedy', 'Rohit Shetty', 'Shah Rukh Khan, Deepika Padukone', '12.jpg');

INSERT INTO Movie (title, description, release_date, duration, genre, director, cast, image) VALUES ('Padmaavat', 'An epic historical drama based on the legend of Rani Padmini, showcasing valor, sacrifice, and love.', '2023-01-25', 163, 'Drama, History', 'Sanjay Leela Bhansali', 'Deepika Padukone, Ranveer Singh', '13.jpg');

INSERT INTO Movie (title, description, release_date, duration, genre, director, cast, image) VALUES ('Lagaan: Once Upon a Time in India', 'An inspiring sports drama set during the British Raj in India, where a group of villagers challenges the British rulers to a game of cricket.', '2023-06-15', 224, 'Drama, Sports', 'Ashutosh Gowariker', 'Aamir Khan, Gracy Singh', '14.jpg');

INSERT INTO Movie (title, description, release_date, duration, genre, director, cast, image) VALUES ('Kuch Kuch Hota Hai', 'A tale of friendship, love, and second chances, as two best friends realize their true feelings for each other.', '2023-10-16', 185, 'Romance, Drama', 'Karan Johar', 'Shah Rukh Khan, Kajol, Rani Mukerji', '15.jpg');

INSERT INTO Movie (title, description, release_date, duration, genre, director, cast, image) VALUES ('Dil Chahta Hai', 'A coming-of-age film that explores the bonds of friendship and the complexities of relationships.', '2023-07-24', 183, 'Drama, Romance', 'Farhan Akhtar', 'Aamir Khan, Saif Ali Khan, Akshaye Khanna', '16.jpg');

INSERT INTO Movie (title, description, release_date, duration, genre, director, cast, image) VALUES ('Kabir Singh', 'A passionate and intense love story of a brilliant but self-destructive surgeon.', '2023-06-21', 175, 'Drama, Romance', 'Sandeep Reddy Vanga', 'Shahid Kapoor, Kiara Advani', '17.jpg');

INSERT INTO Movie (title, description, release_date, duration, genre, director, cast, image) VALUES ('Queen', 'A heartwarming journey of self-discovery as a young woman goes on her honeymoon alone and finds herself along the way.', '2023-03-07', 146, 'Comedy, Drama', 'Vikas Bahl', 'Kangana Ranaut', '18.jpg');

INSERT INTO Movie (title, description, release_date, duration, genre, director, cast, image) VALUES ('Gully Boy', 'A story of an aspiring rapper from the slums of Mumbai who defies societal norms to pursue his passion.', '2023-02-14', 153, 'Drama, Music', 'Zoya Akhtar', 'Ranveer Singh, Alia Bhatt', '19.jpg');

INSERT INTO Movie (title, description, release_date, duration, genre, director, cast, image) VALUES ('Inception', 'A mind-bending science fiction thriller where a skilled thief enters peoples dreams to steal information.', '2023-04-07', 148, 'Sci-Fi, Thriller', 'Christopher Nolan', 'Leonardo DiCaprio, Joseph Gordon-Levitt', '20.jpg');

-------------------------------------------------------------------------------------------------------

INSERT INTO Theatre (name, address, city, state, country)
VALUES ('PVR', 'Hadapsar', 'Pune', 'Maharashtra', 'India');
INSERT INTO Theatre (name, address, city, state, country)
VALUES ('PVR SHOW', 'Sadashiv peth', 'Pune', 'Maharashtra', 'India');
INSERT INTO Theatre (name, address, city, state, country)
VALUES ('Rahul 70mm', 'Manapa', 'Pune', 'Maharashtra', 'India');
INSERT INTO Theatre (name, address, city, state, country)
VALUES ('Cinepolis', 'Shivajinagar', 'Pune', 'Maharashtra', 'India');

INSERT INTO Theatre (name, address, city, state, country)
VALUES ('Alka talkies', 'Alka chowk', 'Mumbai', 'Maharashtra', 'India');
INSERT INTO Theatre (name, address, city, state, country)
VALUES ('Pavillion', 'Koregaon park', 'Mumbai', 'Maharashtra', 'India');
INSERT INTO Theatre (name, address, city, state, country)
VALUES ('Sonam', 'Dadar', 'Mumbai', 'Maharashtra', 'India');
INSERT INTO Theatre (name, address, city, state, country)
VALUES ('Rajdhani', 'Andheri', 'Mumbai', 'Maharashtra', 'India');

INSERT INTO Theatre (name, address, city, state, country) 
VALUES ('PVR DYP City Mall', 'Tarabai Park', 'Kolhapur', 'Maharashtra', 'India');
INSERT INTO Theatre (name, address, city, state, country) 
VALUES ('INOX Reliance Mall', 'Sambhaji Nagar', 'Kolhapur', 'Maharashtra', 'India');
INSERT INTO Theatre (name, address, city, state, country) 
VALUES ('City Pride Multiplex', 'Shahupuri', 'Kolhapur', 'Maharashtra', 'India');
INSERT INTO Theatre (name, address, city, state, country) 
VALUES ('Panchshil Multiplex', 'Rajarampuri', 'Kolhapur', 'Maharashtra', 'India');


--------------------------------------------------------------------------------------------------



INSERT INTO Screen (name, capacity, theatre_id)
VALUES ('Screen 1', 20, 1);
INSERT INTO Screen (name, capacity, theatre_id)
VALUES ('Screen 1', 20, 2);
INSERT INTO Screen (name, capacity, theatre_id)
VALUES ('Screen 1', 20, 3);
INSERT INTO Screen (name, capacity, theatre_id)
VALUES ('Screen 1', 20, 4);
INSERT INTO Screen (name, capacity, theatre_id)
VALUES ('Screen 1', 20, 5);
INSERT INTO Screen (name, capacity, theatre_id)
VALUES ('Screen 1', 20, 6);
INSERT INTO Screen (name, capacity, theatre_id)
VALUES ('Screen 1', 20, 7);
INSERT INTO Screen (name, capacity, theatre_id)
VALUES ('Screen 1', 20, 8);
INSERT INTO Screen (name, capacity, theatre_id)
VALUES ('Screen 1', 20, 9);
INSERT INTO Screen (name, capacity, theatre_id)
VALUES ('Screen 1', 20, 10);
INSERT INTO Screen (name, capacity, theatre_id)
VALUES ('Screen 1', 20, 11);
INSERT INTO Screen (name, capacity, theatre_id)
VALUES ('Screen 1', 20, 12);


INSERT INTO Screen (name, capacity, theatre_id)
VALUES ('Screen 2', 20, 1);
INSERT INTO Screen (name, capacity, theatre_id)
VALUES ('Screen 2', 20, 2);
INSERT INTO Screen (name, capacity, theatre_id)
VALUES ('Screen 2', 20, 3);
INSERT INTO Screen (name, capacity, theatre_id)
VALUES ('Screen 2', 20, 4);
INSERT INTO Screen (name, capacity, theatre_id)
VALUES ('Screen 2', 20, 5);
INSERT INTO Screen (name, capacity, theatre_id)
VALUES ('Screen 2', 20, 6);
INSERT INTO Screen (name, capacity, theatre_id)
VALUES ('Screen 2', 20, 7);
INSERT INTO Screen (name, capacity, theatre_id)
VALUES ('Screen w', 20, 8);
INSERT INTO Screen (name, capacity, theatre_id)
VALUES ('Screen 2', 20, 9);
INSERT INTO Screen (name, capacity, theatre_id)
VALUES ('Screen 2', 20, 10);
INSERT INTO Screen (name, capacity, theatre_id)
VALUES ('Screen 2', 20, 11);
INSERT INTO Screen (name, capacity, theatre_id)
VALUES ('Screen 2', 20, 12);

--------------------------------------------------------------------------------------------------------

INSERT INTO Shows (theatre_id, screen_id, movie_id, show_date, start_time, end_time)
VALUES (1, 1, 1, CURDATE(), CONCAT(CURDATE(), ' 10:00:00'), CONCAT(CURDATE(), ' 13:00:00'));
INSERT INTO Shows (theatre_id, screen_id, movie_id, show_date, start_time, end_time)
VALUES (2, 1, 2, CURDATE(), CONCAT(CURDATE(), ' 10:00:00'), CONCAT(CURDATE(), ' 13:00:00'));
INSERT INTO Shows (theatre_id, screen_id, movie_id, show_date, start_time, end_time)
VALUES (3, 1, 3, CURDATE(), CONCAT(CURDATE(), ' 10:00:00'), CONCAT(CURDATE(), ' 13:00:00'));
INSERT INTO Shows (theatre_id, screen_id, movie_id, show_date, start_time, end_time)
VALUES (4, 1, 4, CURDATE(), CONCAT(CURDATE(), ' 10:00:00'), CONCAT(CURDATE(), ' 13:00:00'));
INSERT INTO Shows (theatre_id, screen_id, movie_id, show_date, start_time, end_time)
VALUES (5, 1, 5, CURDATE(), CONCAT(CURDATE(), ' 10:00:00'), CONCAT(CURDATE(), ' 13:00:00'));
INSERT INTO Shows (theatre_id, screen_id, movie_id, show_date, start_time, end_time)
VALUES (6, 1, 6, CURDATE(), CONCAT(CURDATE(), ' 10:00:00'), CONCAT(CURDATE(), ' 13:00:00'));
INSERT INTO Shows (theatre_id, screen_id, movie_id, show_date, start_time, end_time)
VALUES (7, 1, 7, CURDATE(), CONCAT(CURDATE(), ' 10:00:00'), CONCAT(CURDATE(), ' 13:00:00'));
INSERT INTO Shows (theatre_id, screen_id, movie_id, show_date, start_time, end_time)
VALUES (8, 1, 8, CURDATE(), CONCAT(CURDATE(), ' 10:00:00'), CONCAT(CURDATE(), ' 13:00:00'));
INSERT INTO Shows (theatre_id, screen_id, movie_id, show_date, start_time, end_time)
VALUES (9, 1, 9, CURDATE(), CONCAT(CURDATE(), ' 10:00:00'), CONCAT(CURDATE(), ' 13:00:00'));
INSERT INTO Shows (theatre_id, screen_id, movie_id, show_date, start_time, end_time)
VALUES (10, 1, 10, CURDATE(), CONCAT(CURDATE(), ' 10:00:00'), CONCAT(CURDATE(), ' 13:00:00'));
INSERT INTO Shows (theatre_id, screen_id, movie_id, show_date, start_time, end_time)
VALUES (11, 1, 11, CURDATE(), CONCAT(CURDATE(), ' 10:00:00'), CONCAT(CURDATE(), ' 13:00:00'));
INSERT INTO Shows (theatre_id, screen_id, movie_id, show_date, start_time, end_time)
VALUES (12, 1, 12, CURDATE(), CONCAT(CURDATE(), ' 10:00:00'), CONCAT(CURDATE(), ' 13:00:00'));


INSERT INTO Shows (theatre_id, screen_id, movie_id, show_date, start_time, end_time)
VALUES (1, 2, 1, CURDATE(), CONCAT(CURDATE(), ' 15:00:00'), CONCAT(CURDATE(), ' 18:00:00'));
INSERT INTO Shows (theatre_id, screen_id, movie_id, show_date, start_time, end_time)
VALUES (2, 2, 2, CURDATE(), CONCAT(CURDATE(), ' 15:00:00'), CONCAT(CURDATE(), ' 18:00:00'));
INSERT INTO Shows (theatre_id, screen_id, movie_id, show_date, start_time, end_time)
VALUES (3, 2, 3, CURDATE(), CONCAT(CURDATE(), ' 15:00:00'), CONCAT(CURDATE(), ' 18:00:00'));
INSERT INTO Shows (theatre_id, screen_id, movie_id, show_date, start_time, end_time)
VALUES (4, 2, 4, CURDATE(), CONCAT(CURDATE(), ' 15:00:00'), CONCAT(CURDATE(), ' 18:00:00'));
INSERT INTO Shows (theatre_id, screen_id, movie_id, show_date, start_time, end_time)
VALUES (5, 2, 5, CURDATE(), CONCAT(CURDATE(), ' 15:00:00'), CONCAT(CURDATE(), ' 18:00:00'));
INSERT INTO Shows (theatre_id, screen_id, movie_id, show_date, start_time, end_time)
VALUES (6, 2, 6, CURDATE(), CONCAT(CURDATE(), ' 15:00:00'), CONCAT(CURDATE(), ' 18:00:00'));
INSERT INTO Shows (theatre_id, screen_id, movie_id, show_date, start_time, end_time)
VALUES (7, 2, 7, CURDATE(), CONCAT(CURDATE(), ' 15:00:00'), CONCAT(CURDATE(), ' 18:00:00'));
INSERT INTO Shows (theatre_id, screen_id, movie_id, show_date, start_time, end_time)
VALUES (8, 2, 8, CURDATE(), CONCAT(CURDATE(), ' 15:00:00'), CONCAT(CURDATE(), ' 18:00:00'));
INSERT INTO Shows (theatre_id, screen_id, movie_id, show_date, start_time, end_time)
VALUES (9, 2, 9, CURDATE(), CONCAT(CURDATE(), ' 15:00:00'), CONCAT(CURDATE(), ' 18:00:00'));
INSERT INTO Shows (theatre_id, screen_id, movie_id, show_date, start_time, end_time)
VALUES (10, 2, 10, CURDATE(), CONCAT(CURDATE(), ' 15:00:00'), CONCAT(CURDATE(), ' 18:00:00'));
INSERT INTO Shows (theatre_id, screen_id, movie_id, show_date, start_time, end_time)
VALUES (11, 2, 11, CURDATE(), CONCAT(CURDATE(), ' 15:00:00'), CONCAT(CURDATE(), ' 18:00:00'));
INSERT INTO Shows (theatre_id, screen_id, movie_id, show_date, start_time, end_time)
VALUES (12, 2, 12, CURDATE(), CONCAT(CURDATE(), ' 15:00:00'), CONCAT(CURDATE(), ' 18:00:00'));



------------------------------------------------------------------------------------------------
-- For Theatre 1 Screen 1
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (1, 1, 'A', 1, 'Standard', false, 100.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (1, 1, 'A', 2, 'Standard', false, 100.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (1, 1, 'A', 3, 'Standard', false, 100.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (1, 1, 'A', 4, 'Standard', false, 100.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (1, 1, 'A', 5, 'Standard', false, 100.00);

INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (1, 1, 'B', 1, 'Premium', false, 150.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (1, 1, 'B', 2, 'Premium', false, 150.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (1, 1, 'B', 3, 'Premium', false, 150.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (1, 1, 'B', 4, 'Premium', false, 150.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (1, 1, 'B', 5, 'Premium', false, 150.00);

INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (1, 1, 'C', 1, 'VIP', false, 200.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (1, 1, 'C', 2, 'VIP', false, 200.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (1, 1, 'C', 3, 'VIP', false, 200.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (1, 1, 'C', 4, 'VIP', false, 200.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (1, 1, 'C', 5, 'VIP', false, 200.00);

INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (1, 1, 'D', 1, 'Balcony', false, 250.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (1, 1, 'D', 2, 'Balcony', false, 250.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (1, 1, 'D', 3, 'Balcony', false, 250.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (1, 1, 'D', 4, 'Balcony', false, 250.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (1, 1, 'D', 5, 'Balcony', false, 250.00);

-- For Theatre 1, Screen 2
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (1, 2, 'A', 1, 'Standard', false, 100.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (1, 2, 'A', 2, 'Standard', false, 100.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (1, 2, 'A', 3, 'Standard', false, 100.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (1, 2, 'A', 4, 'Standard', false, 100.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (1, 2, 'A', 5, 'Standard', false, 100.00);

INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (1, 2, 'B', 1, 'Premium', false, 150.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (1, 2, 'B', 2, 'Premium', false, 150.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (1, 2, 'B', 3, 'Premium', false, 150.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (1, 2, 'B', 4, 'Premium', false, 150.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (1, 2, 'B', 5, 'Premium', false, 150.00);

INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (1, 2, 'C', 1, 'VIP', false, 200.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (1, 2, 'C', 2, 'VIP', false, 200.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (1, 2, 'C', 3, 'VIP', false, 200.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (1, 2, 'C', 4, 'VIP', false, 200.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (1, 2, 'C', 5, 'VIP', false, 200.00);

INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (1, 2, 'D', 1, 'Balcony', false, 250.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (1, 2, 'D', 2, 'Balcony', false, 250.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (1, 2, 'D', 3, 'Balcony', false, 250.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (1, 2, 'D', 4, 'Balcony', false, 250.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (1, 2, 'D', 5, 'Balcony', false, 250.00);



-- For Theatre 2, Screen 1
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (2, 1, 'A', 1, 'Standard', false, 100.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (2, 1, 'A', 2, 'Standard', false, 100.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (2, 1, 'A', 3, 'Standard', false, 100.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (2, 1, 'A', 4, 'Standard', false, 100.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (2, 1, 'A', 5, 'Standard', false, 100.00);

INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (2, 1, 'B', 1, 'Premium', false, 150.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (2, 1, 'B', 2, 'Premium', false, 150.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (2, 1, 'B', 3, 'Premium', false, 150.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (2, 1, 'B', 4, 'Premium', false, 150.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (2, 1, 'B', 5, 'Premium', false, 150.00);

INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (2, 1, 'C', 1, 'VIP', false, 200.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (2, 1, 'C', 2, 'VIP', false, 200.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (2, 1, 'C', 3, 'VIP', false, 200.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (2, 1, 'C', 4, 'VIP', false, 200.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (2, 1, 'C', 5, 'VIP', false, 200.00);

INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (2, 1, 'D', 1, 'Balcony', false, 250.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (2, 1, 'D', 2, 'Balcony', false, 250.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (2, 1, 'D', 3, 'Balcony', false, 250.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (2, 1, 'D', 4, 'Balcony', false, 250.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (2, 1, 'D', 5, 'Balcony', false, 250.00);

-- For Theatre 2, Screen 2
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (2, 2, 'A', 1, 'Standard', false, 100.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (2, 2, 'A', 2, 'Standard', false, 100.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (2, 2, 'A', 3, 'Standard', false, 100.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (2, 2, 'A', 4, 'Standard', false, 100.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (2, 2, 'A', 5, 'Standard', false, 100.00);

INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (2, 2, 'B', 1, 'Premium', false, 150.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (2, 2, 'B', 2, 'Premium', false, 150.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (2, 2, 'B', 3, 'Premium', false, 150.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (2, 2, 'B', 4, 'Premium', false, 150.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (2, 2, 'B', 5, 'Premium', false, 150.00);

INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (2, 2, 'C', 1, 'VIP', false, 200.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (2, 2, 'C', 2, 'VIP', false, 200.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (2, 2, 'C', 3, 'VIP', false, 200.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (2, 2, 'C', 4, 'VIP', false, 200.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (2, 2, 'C', 5, 'VIP', false, 200.00);

INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (2, 2, 'D', 1, 'Balcony', false, 250.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (2, 2, 'D', 2, 'Balcony', false, 250.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (2, 2, 'D', 3, 'Balcony', false, 250.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (2, 2, 'D', 4, 'Balcony', false, 250.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (2, 2, 'D', 5, 'Balcony', false, 250.00);


-- For Theatre 3, Screen 1
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (3, 1, 'A', 1, 'Standard', false, 100.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (3, 1, 'A', 2, 'Standard', false, 100.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (3, 1, 'A', 3, 'Standard', false, 100.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (3, 1, 'A', 4, 'Standard', false, 100.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (3, 1, 'A', 5, 'Standard', false, 100.00);

INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (3, 1, 'B', 1, 'Premium', false, 150.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (3, 1, 'B', 2, 'Premium', false, 150.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (3, 1, 'B', 3, 'Premium', false, 150.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (3, 1, 'B', 4, 'Premium', false, 150.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (3, 1, 'B', 5, 'Premium', false, 150.00);

INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (3, 1, 'C', 1, 'VIP', false, 200.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (3, 1, 'C', 2, 'VIP', false, 200.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (3, 1, 'C', 3, 'VIP', false, 200.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (3, 1, 'C', 4, 'VIP', false, 200.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (3, 1, 'C', 5, 'VIP', false, 200.00);

INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (3, 1, 'D', 1, 'Balcony', false, 250.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (3, 1, 'D', 2, 'Balcony', false, 250.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (3, 1, 'D', 3, 'Balcony', false, 250.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (3, 1, 'D', 4, 'Balcony', false, 250.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (3, 1, 'D', 5, 'Balcony', false, 250.00);


-- For Theatre 3, Screen 2
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (3, 2, 'A', 1, 'Standard', false, 100.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (3, 2, 'A', 2, 'Standard', false, 100.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (3, 2, 'A', 3, 'Standard', false, 100.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (3, 2, 'A', 4, 'Standard', false, 100.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (3, 2, 'A', 5, 'Standard', false, 100.00);

INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (3, 2, 'B', 1, 'Premium', false, 150.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (3, 2, 'B', 2, 'Premium', false, 150.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (3, 2, 'B', 3, 'Premium', false, 150.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (3, 2, 'B', 4, 'Premium', false, 150.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (3, 2, 'B', 5, 'Premium', false, 150.00);

INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (3, 2, 'C', 1, 'VIP', false, 200.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (3, 2, 'C', 2, 'VIP', false, 200.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (3, 2, 'C', 3, 'VIP', false, 200.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (3, 2, 'C', 4, 'VIP', false, 200.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (3, 2, 'C', 5, 'VIP', false, 200.00);

INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (3, 2, 'D', 1, 'Balcony', false, 250.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (3, 2, 'D', 2, 'Balcony', false, 250.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (3, 2, 'D', 3, 'Balcony', false, 250.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (3, 2, 'D', 4, 'Balcony', false, 250.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (3, 2, 'D', 5, 'Balcony', false, 250.00);

-- Theatre 4 Screen 1
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (4, 1, 'A', 1, 'Standard', false, 100.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (4, 1, 'A', 2, 'Standard', false, 100.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (4, 1, 'A', 3, 'Standard', false, 100.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (4, 1, 'A', 4, 'Standard', false, 100.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (4, 1, 'A', 5, 'Standard', false, 100.00);

INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (4, 1, 'B', 1, 'Premium', false, 150.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (4, 1, 'B', 2, 'Premium', false, 150.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (4, 1, 'B', 3, 'Premium', false, 150.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (4, 1, 'B', 4, 'Premium', false, 150.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (4, 1, 'B', 5, 'Premium', false, 150.00);

INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (4, 1, 'C', 1, 'VIP', false, 200.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (4, 1, 'C', 2, 'VIP', false, 200.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (4, 1, 'C', 3, 'VIP', false, 200.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (4, 1, 'C', 4, 'VIP', false, 200.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (4, 1, 'C', 5, 'VIP', false, 200.00);

INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (4, 1, 'D', 1, 'Balcony', false, 250.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (4, 1, 'D', 2, 'Balcony', false, 250.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (4, 1, 'D', 3, 'Balcony', false, 250.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (4, 1, 'D', 4, 'Balcony', false, 250.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (4, 1, 'D', 5, 'Balcony', false, 250.00);


-- Theatre 4 Screen 2

INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (4, 2, 'A', 1, 'Standard', false, 100.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (4, 2, 'A', 2, 'Standard', false, 100.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (4, 2, 'A', 3, 'Standard', false, 100.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (4, 2, 'A', 4, 'Standard', false, 100.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (4, 2, 'A', 5, 'Standard', false, 100.00);

INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (4, 2, 'B', 1, 'Premium', false, 150.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (4, 2, 'B', 2, 'Premium', false, 150.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (4, 2, 'B', 3, 'Premium', false, 150.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (4, 2, 'B', 4, 'Premium', false, 150.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (4, 2, 'B', 5, 'Premium', false, 150.00);

INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (4, 2, 'C', 1, 'VIP', false, 200.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (4, 2, 'C', 2, 'VIP', false, 200.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (4, 2, 'C', 3, 'VIP', false, 200.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (4, 2, 'C', 4, 'VIP', false, 200.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (4, 2, 'C', 5, 'VIP', false, 200.00);

INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (4, 2, 'D', 1, 'Balcony', false, 250.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (4, 2, 'D', 2, 'Balcony', false, 250.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (4, 2, 'D', 3, 'Balcony', false, 250.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (4, 2, 'D', 4, 'Balcony', false, 250.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (4, 2, 'D', 5, 'Balcony', false, 250.00);

-- Theatre 5 Screen 1

INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (5, 1, 'A', 1, 'Standard', false, 100.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (5, 1, 'A', 2, 'Standard', false, 100.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (5, 1, 'A', 3, 'Standard', false, 100.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (5, 1, 'A', 4, 'Standard', false, 100.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (5, 1, 'A', 5, 'Standard', false, 100.00);

INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (5, 1, 'B', 1, 'Premium', false, 150.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (5, 1, 'B', 2, 'Premium', false, 150.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (5, 1, 'B', 3, 'Premium', false, 150.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (5, 1, 'B', 4, 'Premium', false, 150.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (5, 1, 'B', 5, 'Premium', false, 150.00);

INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (5, 1, 'C', 1, 'VIP', false, 200.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (5, 1, 'C', 2, 'VIP', false, 200.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (5, 1, 'C', 3, 'VIP', false, 200.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (5, 1, 'C', 4, 'VIP', false, 200.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (5, 1, 'C', 5, 'VIP', false, 200.00);

INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (5, 1, 'D', 1, 'Balcony', false, 250.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (5, 1, 'D', 2, 'Balcony', false, 250.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (5, 1, 'D', 3, 'Balcony', false, 250.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (5, 1, 'D', 4, 'Balcony', false, 250.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (5, 1, 'D', 5, 'Balcony', false, 250.00);


-- Theatre 5 Screen 2
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (5, 2, 'A', 1, 'Standard', false, 100.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (5, 2, 'A', 2, 'Standard', false, 100.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (5, 2, 'A', 3, 'Standard', false, 100.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (5, 2, 'A', 4, 'Standard', false, 100.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (5, 2, 'A', 5, 'Standard', false, 100.00);

INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (5, 2, 'B', 1, 'Premium', false, 150.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (5, 2, 'B', 2, 'Premium', false, 150.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (5, 2, 'B', 3, 'Premium', false, 150.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (5, 2, 'B', 4, 'Premium', false, 150.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (5, 2, 'B', 5, 'Premium', false, 150.00);

INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (5, 2, 'C', 1, 'VIP', false, 200.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (5, 2, 'C', 2, 'VIP', false, 200.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (5, 2, 'C', 3, 'VIP', false, 200.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (5, 2, 'C', 4, 'VIP', false, 200.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (5, 2, 'C', 5, 'VIP', false, 200.00);

INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (5, 2, 'D', 1, 'Balcony', false, 250.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (5, 2, 'D', 2, 'Balcony', false, 250.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (5, 2, 'D', 3, 'Balcony', false, 250.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (5, 2, 'D', 4, 'Balcony', false, 250.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (5, 2, 'D', 5, 'Balcony', false, 250.00);


-- Theatre 6 Screen 1
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (6, 1, 'A', 1, 'Standard', false, 100.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (6, 1, 'A', 2, 'Standard', false, 100.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (6, 1, 'A', 3, 'Standard', false, 100.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (6, 1, 'A', 4, 'Standard', false, 100.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (6, 1, 'A', 5, 'Standard', false, 100.00);

INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (6, 1, 'B', 1, 'Premium', false, 150.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (6, 1, 'B', 2, 'Premium', false, 150.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (6, 1, 'B', 3, 'Premium', false, 150.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (6, 1, 'B', 4, 'Premium', false, 150.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (6, 1, 'B', 5, 'Premium', false, 150.00);

INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (6, 1, 'C', 1, 'VIP', false, 200.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (6, 1, 'C', 2, 'VIP', false, 200.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (6, 1, 'C', 3, 'VIP', false, 200.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (6, 1, 'C', 4, 'VIP', false, 200.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (6, 1, 'C', 5, 'VIP', false, 200.00);

INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (6, 1, 'D', 1, 'Balcony', false, 250.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (6, 1, 'D', 2, 'Balcony', false, 250.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (6, 1, 'D', 3, 'Balcony', false, 250.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (6, 1, 'D', 4, 'Balcony', false, 250.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (6, 1, 'D', 5, 'Balcony', false, 250.00);

-- Theatre 6 Screen 2
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (6, 2, 'A', 1, 'Standard', false, 100.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (6, 2, 'A', 2, 'Standard', false, 100.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (6, 2, 'A', 3, 'Standard', false, 100.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (6, 2, 'A', 4, 'Standard', false, 100.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (6, 2, 'A', 5, 'Standard', false, 100.00);

INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (6, 2, 'B', 1, 'Premium', false, 150.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (6, 2, 'B', 2, 'Premium', false, 150.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (6, 2, 'B', 3, 'Premium', false, 150.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (6, 2, 'B', 4, 'Premium', false, 150.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (6, 2, 'B', 5, 'Premium', false, 150.00);

INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (6, 2, 'C', 1, 'VIP', false, 200.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (6, 2, 'C', 2, 'VIP', false, 200.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (6, 2, 'C', 3, 'VIP', false, 200.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (6, 2, 'C', 4, 'VIP', false, 200.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (6, 2, 'C', 5, 'VIP', false, 200.00);

INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (6, 2, 'D', 1, 'Balcony', false, 250.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (6, 2, 'D', 2, 'Balcony', false, 250.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (6, 2, 'D', 3, 'Balcony', false, 250.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (6, 2, 'D', 4, 'Balcony', false, 250.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (6, 2, 'D', 5, 'Balcony', false, 250.00);


-- Theatre 7 Screen 1
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (7, 1, 'A', 1, 'Standard', false, 100.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (7, 1, 'A', 2, 'Standard', false, 100.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (7, 1, 'A', 3, 'Standard', false, 100.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (7, 1, 'A', 4, 'Standard', false, 100.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (7, 1, 'A', 5, 'Standard', false, 100.00);

INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (7, 1, 'B', 1, 'Premium', false, 150.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (7, 1, 'B', 2, 'Premium', false, 150.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (7, 1, 'B', 3, 'Premium', false, 150.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (7, 1, 'B', 4, 'Premium', false, 150.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (7, 1, 'B', 5, 'Premium', false, 150.00);

INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (7, 1, 'C', 1, 'VIP', false, 200.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (7, 1, 'C', 2, 'VIP', false, 200.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (7, 1, 'C', 3, 'VIP', false, 200.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (7, 1, 'C', 4, 'VIP', false, 200.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (7, 1, 'C', 5, 'VIP', false, 200.00);

INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (7, 1, 'D', 1, 'Balcony', false, 250.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (7, 1, 'D', 2, 'Balcony', false, 250.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (7, 1, 'D', 3, 'Balcony', false, 250.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (7, 1, 'D', 4, 'Balcony', false, 250.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (7, 1, 'D', 5, 'Balcony', false, 250.00);


-- Theatre 7 Screen 2

INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (7, 2, 'A', 1, 'Standard', false, 100.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (7, 2, 'A', 2, 'Standard', false, 100.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (7, 2, 'A', 3, 'Standard', false, 100.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (7, 2, 'A', 4, 'Standard', false, 100.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (7, 2, 'A', 5, 'Standard', false, 100.00);

INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (7, 2, 'B', 1, 'Premium', false, 150.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (7, 2, 'B', 2, 'Premium', false, 150.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (7, 2, 'B', 3, 'Premium', false, 150.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (7, 2, 'B', 4, 'Premium', false, 150.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (7, 2, 'B', 5, 'Premium', false, 150.00);

INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (7, 2, 'C', 1, 'VIP', false, 200.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (7, 2, 'C', 2, 'VIP', false, 200.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (7, 2, 'C', 3, 'VIP', false, 200.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (7, 2, 'C', 4, 'VIP', false, 200.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (7, 2, 'C', 5, 'VIP', false, 200.00);

INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (7, 2, 'D', 1, 'Balcony', false, 250.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (7, 2, 'D', 2, 'Balcony', false, 250.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (7, 2, 'D', 3, 'Balcony', false, 250.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (7, 2, 'D', 4, 'Balcony', false, 250.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (7, 2, 'D', 5, 'Balcony', false, 250.00);

-- Theatre 8 Screen 1
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (8, 1, 'A', 1, 'Standard', false, 100.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (8, 1, 'A', 2, 'Standard', false, 100.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (8, 1, 'A', 3, 'Standard', false, 100.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (8, 1, 'A', 4, 'Standard', false, 100.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (8, 1, 'A', 5, 'Standard', false, 100.00);

INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (8, 1, 'B', 1, 'Premium', false, 150.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (8, 1, 'B', 2, 'Premium', false, 150.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (8, 1, 'B', 3, 'Premium', false, 150.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (8, 1, 'B', 4, 'Premium', false, 150.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (8, 1, 'B', 5, 'Premium', false, 150.00);

INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (8, 1, 'C', 1, 'VIP', false, 200.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (8, 1, 'C', 2, 'VIP', false, 200.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (8, 1, 'C', 3, 'VIP', false, 200.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (8, 1, 'C', 4, 'VIP', false, 200.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (8, 1, 'C', 5, 'VIP', false, 200.00);

INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (8, 1, 'D', 1, 'Balcony', false, 250.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (8, 1, 'D', 2, 'Balcony', false, 250.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (8, 1, 'D', 3, 'Balcony', false, 250.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (8, 1, 'D', 4, 'Balcony', false, 250.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (8, 1, 'D', 5, 'Balcony', false, 250.00);


-- Theatre 8 Screen 2

INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (8, 2, 'A', 1, 'Standard', false, 100.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (8, 2, 'A', 2, 'Standard', false, 100.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (8, 2, 'A', 3, 'Standard', false, 100.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (8, 2, 'A', 4, 'Standard', false, 100.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (8, 2, 'A', 5, 'Standard', false, 100.00);

INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (8, 2, 'B', 1, 'Premium', false, 150.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (8, 2, 'B', 2, 'Premium', false, 150.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (8, 2, 'B', 3, 'Premium', false, 150.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (8, 2, 'B', 4, 'Premium', false, 150.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (8, 2, 'B', 5, 'Premium', false, 150.00);

INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (8, 2, 'C', 1, 'VIP', false, 200.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (8, 2, 'C', 2, 'VIP', false, 200.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (8, 2, 'C', 3, 'VIP', false, 200.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (8, 2, 'C', 4, 'VIP', false, 200.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (8, 2, 'C', 5, 'VIP', false, 200.00);

INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (8, 2, 'D', 1, 'Balcony', false, 250.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (8, 2, 'D', 2, 'Balcony', false, 250.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (8, 2, 'D', 3, 'Balcony', false, 250.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (8, 2, 'D', 4, 'Balcony', false, 250.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (8, 2, 'D', 5, 'Balcony', false, 250.00);


-- Theatre 9 Screen 1

INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (9, 1, 'A', 1, 'Standard', false, 100.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (9, 1, 'A', 2, 'Standard', false, 100.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (9, 1, 'A', 3, 'Standard', false, 100.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (9, 1, 'A', 4, 'Standard', false, 100.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (9, 1, 'A', 5, 'Standard', false, 100.00);

INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (9, 1, 'B', 1, 'Premium', false, 150.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (9, 1, 'B', 2, 'Premium', false, 150.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (9, 1, 'B', 3, 'Premium', false, 150.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (9, 1, 'B', 4, 'Premium', false, 150.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (9, 1, 'B', 5, 'Premium', false, 150.00);

INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (9, 1, 'C', 1, 'VIP', false, 200.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (9, 1, 'C', 2, 'VIP', false, 200.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (9, 1, 'C', 3, 'VIP', false, 200.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (9, 1, 'C', 4, 'VIP', false, 200.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (9, 1, 'C', 5, 'VIP', false, 200.00);

INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (9, 1, 'D', 1, 'Balcony', false, 250.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (9, 1, 'D', 2, 'Balcony', false, 250.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (9, 1, 'D', 3, 'Balcony', false, 250.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (9, 1, 'D', 4, 'Balcony', false, 250.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (9, 1, 'D', 5, 'Balcony', false, 250.00);


-- For Theatre 9, Screen 2
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (9, 2, 'A', 1, 'Standard', false, 100.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (9, 2, 'A', 2, 'Standard', false, 100.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (9, 2, 'A', 3, 'Standard', false, 100.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (9, 2, 'A', 4, 'Standard', false, 100.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (9, 2, 'A', 5, 'Standard', false, 100.00);

INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (9, 2, 'B', 1, 'Premium', false, 150.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (9, 2, 'B', 2, 'Premium', false, 150.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (9, 2, 'B', 3, 'Premium', false, 150.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (9, 2, 'B', 4, 'Premium', false, 150.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (9, 2, 'B', 5, 'Premium', false, 150.00);

INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (9, 2, 'C', 1, 'VIP', false, 200.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (9, 2, 'C', 2, 'VIP', false, 200.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (9, 2, 'C', 3, 'VIP', false, 200.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (9, 2, 'C', 4, 'VIP', false, 200.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (9, 2, 'C', 5, 'VIP', false, 200.00);

INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (9, 2, 'D', 1, 'Balcony', false, 250.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (9, 2, 'D', 2, 'Balcony', false, 250.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (9, 2, 'D', 3, 'Balcony', false, 250.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (9, 2, 'D', 4, 'Balcony', false, 250.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (9, 2, 'D', 5, 'Balcony', false, 250.00);


-- Theatre 10 Screen 1
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (10, 1, 'A', 1, 'Standard', false, 100.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (10, 1, 'A', 2, 'Standard', false, 100.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (10, 1, 'A', 3, 'Standard', false, 100.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (10, 1, 'A', 4, 'Standard', false, 100.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (10, 1, 'A', 5, 'Standard', false, 100.00);

INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (10, 1, 'B', 1, 'Premium', false, 150.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (10, 1, 'B', 2, 'Premium', false, 150.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (10, 1, 'B', 3, 'Premium', false, 150.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (10, 1, 'B', 4, 'Premium', false, 150.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (10, 1, 'B', 5, 'Premium', false, 150.00);

INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (10, 1, 'C', 1, 'VIP', false, 200.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (10, 1, 'C', 2, 'VIP', false, 200.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (10, 1, 'C', 3, 'VIP', false, 200.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (10, 1, 'C', 4, 'VIP', false, 200.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (10, 1, 'C', 5, 'VIP', false, 200.00);

INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (10, 1, 'D', 1, 'Balcony', false, 250.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (10, 1, 'D', 2, 'Balcony', false, 250.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (10, 1, 'D', 3, 'Balcony', false, 250.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (10, 1, 'D', 4, 'Balcony', false, 250.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (10, 1, 'D', 5, 'Balcony', false, 250.00);

-- Theatre 10 Screen 2

INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (10, 2, 'A', 1, 'Standard', false, 100.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (10, 2, 'A', 2, 'Standard', false, 100.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (10, 2, 'A', 3, 'Standard', false, 100.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (10, 2, 'A', 4, 'Standard', false, 100.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (10, 2, 'A', 5, 'Standard', false, 100.00);

INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (10, 2, 'B', 1, 'Premium', false, 150.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (10, 2, 'B', 2, 'Premium', false, 150.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (10, 2, 'B', 3, 'Premium', false, 150.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (10, 2, 'B', 4, 'Premium', false, 150.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (10, 2, 'B', 5, 'Premium', false, 150.00);

INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (10, 2, 'C', 1, 'VIP', false, 200.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (10, 2, 'C', 2, 'VIP', false, 200.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (10, 2, 'C', 3, 'VIP', false, 200.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (10, 2, 'C', 4, 'VIP', false, 200.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (10, 2, 'C', 5, 'VIP', false, 200.00);

INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (10, 2, 'D', 1, 'Balcony', false, 250.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (10, 2, 'D', 2, 'Balcony', false, 250.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (10, 2, 'D', 3, 'Balcony', false, 250.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (10, 2, 'D', 4, 'Balcony', false, 250.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (10, 2, 'D', 5, 'Balcony', false, 250.00);


-- Theatre 11 Screen 1

INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (11, 1, 'A', 1, 'Standard', false, 100.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (11, 1, 'A', 2, 'Standard', false, 100.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (11, 1, 'A', 3, 'Standard', false, 100.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (11, 1, 'A', 4, 'Standard', false, 100.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (11, 1, 'A', 5, 'Standard', false, 100.00);

INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (11, 1, 'B', 1, 'Premium', false, 150.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (11, 1, 'B', 2, 'Premium', false, 150.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (11, 1, 'B', 3, 'Premium', false, 150.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (11, 1, 'B', 4, 'Premium', false, 150.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (11, 1, 'B', 5, 'Premium', false, 150.00);

INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (11, 1, 'C', 1, 'VIP', false, 200.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (11, 1, 'C', 2, 'VIP', false, 200.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (11, 1, 'C', 3, 'VIP', false, 200.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (11, 1, 'C', 4, 'VIP', false, 200.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (11, 1, 'C', 5, 'VIP', false, 200.00);

INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (11, 1, 'D', 1, 'Balcony', false, 250.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (11, 1, 'D', 2, 'Balcony', false, 250.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (11, 1, 'D', 3, 'Balcony', false, 250.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (11, 1, 'D', 4, 'Balcony', false, 250.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (11, 1, 'D', 5, 'Balcony', false, 250.00);


-- Theatre 11 Screen 2

INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (11, 2, 'A', 1, 'Standard', false, 100.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (11, 2, 'A', 2, 'Standard', false, 100.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (11, 2, 'A', 3, 'Standard', false, 100.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (11, 2, 'A', 4, 'Standard', false, 100.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (11, 2, 'A', 5, 'Standard', false, 100.00);

INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (11, 2, 'B', 1, 'Premium', false, 150.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (11, 2, 'B', 2, 'Premium', false, 150.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (11, 2, 'B', 3, 'Premium', false, 150.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (11, 2, 'B', 4, 'Premium', false, 150.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (11, 2, 'B', 5, 'Premium', false, 150.00);

INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (11, 2, 'C', 1, 'VIP', false, 200.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (11, 2, 'C', 2, 'VIP', false, 200.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (11, 2, 'C', 3, 'VIP', false, 200.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (11, 2, 'C', 4, 'VIP', false, 200.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (11, 2, 'C', 5, 'VIP', false, 200.00);

INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (11, 2, 'D', 1, 'Balcony', false, 250.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (11, 2, 'D', 2, 'Balcony', false, 250.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (11, 2, 'D', 3, 'Balcony', false, 250.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (11, 2, 'D', 4, 'Balcony', false, 250.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (11, 2, 'D', 5, 'Balcony', false, 250.00);


-- Theatre 12 Screen 1

INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (12, 1, 'A', 1, 'Standard', false, 100.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (12, 1, 'A', 2, 'Standard', false, 100.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (12, 1, 'A', 3, 'Standard', false, 100.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (12, 1, 'A', 4, 'Standard', false, 100.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (12, 1, 'A', 5, 'Standard', false, 100.00);

INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (12, 1, 'B', 1, 'Premium', false, 150.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (12, 1, 'B', 2, 'Premium', false, 150.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (12, 1, 'B', 3, 'Premium', false, 150.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (12, 1, 'B', 4, 'Premium', false, 150.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (12, 1, 'B', 5, 'Premium', false, 150.00);

INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (12, 1, 'C', 1, 'VIP', false, 200.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (12, 1, 'C', 2, 'VIP', false, 200.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (12, 1, 'C', 3, 'VIP', false, 200.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (12, 1, 'C', 4, 'VIP', false, 200.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (12, 1, 'C', 5, 'VIP', false, 200.00);

INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (12, 1, 'D', 1, 'Balcony', false, 250.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (12, 1, 'D', 2, 'Balcony', false, 250.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (12, 1, 'D', 3, 'Balcony', false, 250.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (12, 1, 'D', 4, 'Balcony', false, 250.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (12, 1, 'D', 5, 'Balcony', false, 250.00);


-- Theatre 12 Screen 2

INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (12, 2, 'A', 1, 'Standard', false, 100.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (12, 2, 'A', 2, 'Standard', false, 100.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (12, 2, 'A', 3, 'Standard', false, 100.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (12, 2, 'A', 4, 'Standard', false, 100.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (12, 2, 'A', 5, 'Standard', false, 100.00);

INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (12, 2, 'B', 1, 'Premium', false, 150.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (12, 2, 'B', 2, 'Premium', false, 150.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (12, 2, 'B', 3, 'Premium', false, 150.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (12, 2, 'B', 4, 'Premium', false, 150.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (12, 2, 'B', 5, 'Premium', false, 150.00);

INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (12, 2, 'C', 1, 'VIP', false, 200.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (12, 2, 'C', 2, 'VIP', false, 200.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (12, 2, 'C', 3, 'VIP', false, 200.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (12, 2, 'C', 4, 'VIP', false, 200.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (12, 2, 'C', 5, 'VIP', false, 200.00);

INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (12, 2, 'D', 1, 'Balcony', false, 250.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (12, 2, 'D', 2, 'Balcony', false, 250.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (12, 2, 'D', 3, 'Balcony', false, 250.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (12, 2, 'D', 4, 'Balcony', false, 250.00);
INSERT INTO Seats (theatre_id, screen_id, seat_row, seat_number, seat_type, is_reserved, price)
VALUES (12, 2, 'D', 5, 'Balcony', false, 250.00);

------------------------------------------------------------------------------------------------------------------------------


INSERT INTO Booking (user_id, screen_id, show_id, movie_id, seat_id, booking_date, total_tickets, total_amount)
VALUES (1, 1, 1, 1, 1, '2023-07-20', 2, 200.00);
INSERT INTO Booking (user_id, screen_id, show_id, movie_id, seat_id, booking_date, total_tickets, total_amount)
VALUES (2, 2, 2, 2, 2, '2023-07-20', 2, 200.00);


















































