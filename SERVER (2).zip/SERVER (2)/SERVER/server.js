const express = require('express');
const cors = require("cors")
const session = require('express-session');
const mysql = require('mysql')

const userRouter = require('./routers/user');
const movieRouter = require('./routers/movie');
const screenRouter = require('./routers/screen');
const bookingRouter = require('./routers/booking');
const theatreRouter = require('./routers/theatre');
const seatsRouter = require('./routers/seats');
const ticketsRouter = require('./routers/tickets');
const showRouter = require('./routers/show');
const adminRouter = require('./routers/admin');



const app = express()
app.use(express.json())
app.use(cors("*"))


app.use(
  session({
    secret: 'your_secret_key', // Replace 'your_secret_key' with a strong secret key
    resave: false,
    saveUninitialized: false,
  })
);
app.use('/users', userRouter);
app.use('/movie', movieRouter);
app.use('/screens', screenRouter);
app.use('/bookings', bookingRouter);
app.use('/theatres', theatreRouter);
app.use('/seats', seatsRouter);
app.use('/tickets', ticketsRouter);
app.use('/shows', showRouter);
app.use('/admin/movies' , adminRouter);



app.listen(4000, "0.0.0.0", () => {
    console.log('Server is running on port 4000');
  });