const express = require("express")
const db = require("../db")
const utils = require("../utils")

const router = express.Router()


  // done also inserting in the database
  
    // done with the api

// PUT /shows/:id - Update show by ID
// router.put('/:id', (req, res) => {
//   const showId = req.params.id;
//   const { movieId, theatreId, startTime, endTime } = req.body;
//   const query = 'UPDATE Show SET movieId = ?, theatreId = ?, startTime = ?, endTime = ? WHERE id = ?';
//   const values = [movieId, theatreId, startTime, endTime, showId];
//   db.query(query, values, (err, result) => {
//     if (err) {
//       console.error('Error updating show: ' + err.stack);
//       res.status(500).json({ error: 'Error updating show' });
//       return;
//     }
//     res.json({ message: 'Show updated successfully' });
//   });
// });

// // DELETE /shows/:id - Delete show by ID
// router.delete('/:id', (req, res) => {
//   const showId = req.params.id;
//   const query = 'DELETE FROM Show WHERE id = ?';
//   db.query(query, [showId], (err, result) => {
//     if (err) {
//       console.error('Error deleting show: ' + err.stack);
//       res.status(500).json({ error: 'Error deleting show' });
//       return;
//     }
//     res.json({ message: 'Show deleted successfully' });
//   });
// });

  // //add show for a particular movie
  // router.post('admin/shows/add', async (req, res) => {
  //   try {
  //     const {
  //       theatre_id,
  //       screen_id,
  //       movie_id,
  //       show_date,
  //       start_time,
  //       end_time
  //     } = req.body;
    
  //     // Construct the SQL query
  //     const query = `INSERT INTO Shows (theatre_id, screen_id, movie_id, show_date, start_time, end_time) 
  //                    VALUES (?, ?, ?, ?, ?, ?)`;
    
  //     // Execute the query with the provided values
  //     await db.query(query, [theatre_id, screen_id, movie_id, show_date, start_time, end_time]);
    
  //     res.status(200).json({ message: 'Show added successfully' });
  //   } catch (err) {
  //     console.error('Error adding the show: ', err);
  //     res.status(500).json({ error: 'An error occurred while adding the show' });
  //   }
  // });


  // add theatre

  // add screen

  // add seats
  

  module.exports = router;