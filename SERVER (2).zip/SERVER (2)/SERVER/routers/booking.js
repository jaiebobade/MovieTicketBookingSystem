const express = require("express")
const db = require("../db")
const utils = require("../utils")

const router = express.Router()



// GET /bookings - Get all bookings
router.get('/', (req, res) => {
  const query = 'SELECT * FROM Booking';
  db.query(query, (err, results) => {
    if (err) {
      console.error('Error retrieving bookings: ' + err.stack);
      res.status(500).json({ error: 'Error retrieving bookings' });
      return;
    }
    res.json(results);
  });
});


// // GET /bookings/:bookingId - Get booking by booking ID
router.get('/:bookingId', (req, res) => {
  const bookingId = req.params.bookingId;
  const query = 'SELECT * FROM Booking WHERE booking_id = ?';
  db.query(query, [bookingId], (err, result) => {
    if (err) {
      console.error('Error retrieving booking: ' + err.stack);
      res.status(500).json({ error: 'Error retrieving booking' });
      return;
    }
    if (result.length === 0) {
      res.status(404).json({ error: 'Booking not found' });
    } else {
      res.json(result[0]);
    }
  });
});


// POST /bookings - Create a new booking
router.post('/', (req, res) => {
  const { user_id, movie_id, screen_id, show_id, seat_id, booking_date, total_tickets, total_amount } = req.body;
  const query = 'INSERT INTO Booking (user_id, movie_id, screen_id, show_id, seat_id, booking_date, total_tickets, total_amount) VALUES (?, ?, ?, ?, ?, ?, ?, ?)';
  const values = [user_id, movie_id, screen_id, show_id, seat_id, booking_date, total_tickets, total_amount];
  db.query(query, values, (err, result) => {
    if (err) {
      console.error('Error creating booking: ' + err.stack);
      res.status(500).json({ error: 'Error creating booking' });
      return;
    }
    res.json({ message: 'Booking created successfully' });
  });
});


// fetching details to prepare a ticket
router.get('/booking/tickets', (req, res) => {
  const query = `
    SELECT b.booking_id, u.name as user_name, m.title as movie_name, s.name as screen_name,
           st.seat_row, st.seat_number, sh.show_date, sh.start_time, 
           b.total_tickets, b.total_amount
    FROM Booking b
    INNER JOIN User u ON b.user_id = u.user_id
    INNER JOIN Movie m ON b.movie_id = m.movie_id
    INNER JOIN Screen s ON b.screen_id = s.screen_id
    INNER JOIN Seats st ON b.seat_id = st.seat_id
    INNER JOIN Shows sh ON b.show_id = sh.show_id`;

  db.query(query, (err, results) => {
    if (err) {
      console.error('Error retrieving ticket details: ' + err.stack);
      res.status(500).json({ error: 'Error retrieving ticket details' });
      return;
    }

    res.json(results);
  });
});

//fetching details for a particular userID
// GET /tickets for the logged-in user
router.get('/ticket/:userId', (req, res) => {
  const loggedInUserId = req.session.user_id;
  const userId = req.params.userId;
  // This will capture the userId from the URL

  if (!loggedInUserId) {
    res.status(401).json({ error: 'Not logged in' });
    return;
  }

  // Check if the logged-in user is authorized to access the data
  if (loggedInUserId !== userId) {
    res.status(401).json({ error: 'Unauthorized' });
    return;
  }

  const query = `
    SELECT b.booking_id, u.name as user_name, m.title as movie_name, s.name as screen_name,
           st.seat_row, st.seat_number, sh.show_date, sh.start_time, 
           b.total_tickets, b.total_amount
    FROM Booking b
    INNER JOIN User u ON b.user_id = u.user_id
    INNER JOIN Movie m ON b.movie_id = m.movie_id
    INNER JOIN Screen s ON b.screen_id = s.screen_id
    INNER JOIN Seats st ON b.seat_id = st.seat_id
    INNER JOIN Shows sh ON b.show_id = sh.show_id
    WHERE u.user_id = ?`;

  db.query(query, [userId], (err, results) => {
    if (err) {
      console.error('Error retrieving ticket details: ' + err.stack);
      res.status(500).json({ error: 'Error retrieving ticket details' });
      return;
    }

    res.json(results);
  });
});

module.exports = router;
