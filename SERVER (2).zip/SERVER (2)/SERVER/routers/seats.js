const express = require("express")
const db = require("../db")
const utils = require("../utils")

const router = express.Router()



// GET /seats - Get all seats
router.get('/', (req, res) => {
  const query = 'SELECT * FROM Seats';
  
  db.query(query, (err, results) => {
    if (err) {
      console.error('Error retrieving seats: ' + err.stack);
      return res.status(500).json({ error: 'Error retrieving seats' });
    }
    
    res.json(results);
  });
});




// Fetch seats by ID
router.get('/:id', (req, res) => {
  const seatId = req.params.id;
  const query = 'SELECT * FROM Seats WHERE seat_id = ?';
  db.query(query, [seatId], (err, result) => {
    if (err) {
      console.error('Error fetching seat: ', err);
      res.status(500).json({ error: 'Error fetching seat' });
      return;
    }
    if (result.length === 0) {
      res.status(404).json({ message: 'Seat not found' });
      return;
    }
    res.status(200).json(result[0]);
  });
});

// fetching available seats for a show of a movie on a screen of a theatre
// GET /seats/:theatreId/:screenId/:showId 
router.get('/:theatreId/:screenId/:showId', (req, res) => {
  const { theatreId, screenId, showId } = req.params;

  const query = `
    SELECT *
    FROM Seats
    WHERE theatre_id = ? AND screen_id = ? AND seat_id NOT IN (
      SELECT seat_id
      FROM Booking
      WHERE show_id = ?
    )`;
  db.query(query, [theatreId, screenId, showId], (err, results) => {
    if (err) {
      console.error('Error fetching available seats: ' + err.stack);
      return res.status(500).json({ error: 'Error fetching available seats' });
    }
    res.json(results);
  });
});


// fetching booked seats for a show of a movie on a screen of a theatre
// GET /booked/:theatreId/:screenId/:showId/:movieId
router.get('/booked/:theatreId/:screenId/:showId/:movieId', (req, res) => {
  const theatreId = req.params.theatreId;
  const screenId = req.params.screenId;
  const showId = req.params.showId;
  const movieId = req.params.movieId;

  const query = `
    SELECT *
    FROM Seats
    WHERE theatre_id = ? AND screen_id = ? AND seat_id IN (
      SELECT seat_id
      FROM Booking
      WHERE theatre_id = ? AND screen_id = ? AND show_id = ? AND movie_id = ?
    )`;

  db.query(query, [theatreId, screenId, theatreId, screenId, showId, movieId], (err, result) => {
    if (err) {
      console.error('Error fetching booked seats: ' + err.stack);
      res.status(500).json({ error: 'Error fetching booked seats' });
      return;
    }

    res.json(result);
  });
});


// Updating the status of is_reserved =  1 after booking
// POST /seats/booked/:theatreId/:screenId/:showId/:movieId
router.post('/booked/:theatreId/:screenId/:seatId', (req, res) => {
  const theatreId = req.params.theatreId;
  const screenId = req.params.screenId;
  const seatId = req.params.seatId;

  // Assuming you have an array of seat IDs that are booked
  // Replace 'bookedSeatIds' with your actual array of booked seat IDs
  const bookedSeatIds = req.body.bookedSeatIds;

  // Update the 'is_reserved' column to 1 for the booked seats
  const query = `
    UPDATE Seats
    SET is_reserved = 1
    WHERE theatre_id = ? AND screen_id = ? AND seat_id = ?`;

  db.query(query, [theatreId, screenId, seatId, bookedSeatIds], (err, result) => {
    if (err) {
      console.error('Error updating booked seats: ' + err.stack);
      res.status(500).json({ error: 'Error updating booked seats' });
      return;
    }

    res.json({ message: 'Booked seats updated successfully' });
  });
});


module.exports = router;
