const express = require("express")
const db = require("../db")
const utils = require("../utils")

const router = express.Router()


//GET /tickets - Get all tickets
router.get('/', (req, res) => {
  const query = 'SELECT * FROM Tickets';
   db.query(query, (err, results) => {
    if (err) {
       console.error('Error retrieving tickets: ' + err.stack);
       res.status(500).json({ error: 'Error retrieving tickets' });
      return;
    }
    
     res.json(results);
   });
 });

 //GET /tickets/:id - Get ticket by ID
 router.get('/:id', (req, res) => {
   const ticketId = req.params.id;
   const query = 'SELECT * FROM Tickets WHERE id = ?';
   db.query(query, [ticketId], (err, results) => {
     if (err) {
     console.error('Error retrieving ticket: ' + err.stack);
       res.status(500).json({ error: 'Error retrieving ticket' });
       return;
  }
     if (results.length === 0) {
       res.status(404).json({ error: 'Ticket not found' });
     } else {
     res.json(results[0]);
    }
  });
 });



module.exports = router;
