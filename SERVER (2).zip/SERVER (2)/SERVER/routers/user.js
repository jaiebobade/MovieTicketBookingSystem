const express = require("express")
const db = require("../db")
const utils = require("../utils")

const router = express.Router()



// GET /users - Get all users
router.get('/', (req, res) => {
  const query = 'SELECT * FROM User';
  db.query(query, (err, results) => {
    if (err) {
      console.error('Error retrieving users: ' + err.stack);
      res.status(500).json({ error: 'Error retrieving users' });
      return;
    }
    res.json(results);
  });
});

// GET /users/:id - Get user by ID
router.get('/:id', (req, res) => {
  const userId = req.params.id;
  const query = 'SELECT * FROM User WHERE user_id = ?';
  db.query(query, [userId], (err, results) => {
    if (err) {
      console.error('Error retrieving user: ' + err.stack);
      res.status(500).json({ error: 'Error retrieving user' });
      return;
    }
    if (results.length === 0) {
      res.status(404).json({ error: 'User not found' });
    } else {
      res.json(results[0]);
    }
  });
});

// POST /users - Create a new user
router.post('/register', (req, res) => {
  const { username, password, email, name, phone, address } = req.body;
  const query = 'INSERT INTO User (username, password, email, name, phone, address) VALUES (?, ?, ?, ?, ?, ?)';
  const values = [username, password, email, name, phone, address];
  db.query(query, values, (err, result) => {
    if (err) {
      console.error('Error creating user: ' + err.stack);
      res.status(500).json({ error: 'Error creating user' });
      return;
    }
    res.json({ message: 'User created successfully' });
  });
});

// POST /login - The user logs in
router.post('/login', (req, res) => {
  const { username, password } = req.body;
  const sqlSelect = 'SELECT * FROM User WHERE username=? AND password=?';
  const values = [username, password];
  
  db.query(sqlSelect, values, (err, result) => {
    if (err) {
      console.log(err);
      // Send appropriate error response
      res.status(500).send({ message: "Internal Server Error" });
    } else {
      if (result.length > 0) {
        // User login successful
        console.log("** USER LOGIN SUCCESSFUL **");
        // Send success response with user details
        res.status(200).send({message:result});
      } else {
        // Invalid username/password combination
        console.log("** INVALID USERNAME/PASSWORD COMBINATION **");
        // Send error response
        res.status(401).send({ message: "Wrong username/password combination!" });
      }
    }
  });
});



//  // PUT /users/:id - Update user by ID
// router.put('/:id', (req, res) => {
//   const userId = req.params.id;
//   const { username, password, email, name, phone, address } = req.body;
//   const query = 'UPDATE User SET username = ?, password = ?, email = ?, name = ?, phone = ?, address = ? WHERE id = ?';
//   const values = [username, password, email, name, phone, address, userId];
//   db.query(query, values, (err, result) => {
//     if (err) {
//       console.error('Error updating user: ' + err.stack);
//       res.status(500).json({ error: 'Error updating user' });
//       return;
//     }
//     res.json({ message: 'User updated successfully' });
//   });
// });

//DELETE /users/:id - Delete user by ID
router.delete('/:id', (req, res) => {
  const userId = req.params.id;
  const query = 'DELETE FROM User WHERE user_id = ?';
  db.query(query, [userId], (err, result) => {
    if (err) {
      console.error('Error deleting user: ' + err.stack);
      res.status(500).json({ error: 'Error deleting user' });
      return;
    }
    res.json({ message: 'User deleted successfully' });
  });
});


module.exports = router;
