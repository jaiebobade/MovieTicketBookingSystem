const express = require("express")
const db = require("../db")
const utils = require("../utils")

const router = express.Router()


// GET /shows - Get all shows
router.get('/', (req, res) => {
  const query = 'SELECT * FROM Shows';
  db.query(query, (err, results) => {
    if (err) {
      console.error('Error retrieving shows: ' + err.stack);
      res.status(500).json({ error: 'Error retrieving shows' });
      return;
    }
    res.json(results);
  });
});

// GET /shows/:id - Get show by ID
router.get('/:id', (req, res) => {
  const showId = req.params.id;
  const query = 'SELECT * FROM Shows WHERE show_id = ?';
  db.query(query, [showId], (err, results) => {
    if (err) {
      console.error('Error retrieving show: ' + err.stack);
      res.status(500).json({ error: 'Error retrieving show' });
      return;
    }
    if (results.length === 0) {
      res.status(404).json({ error: 'Show not found' });
    } else {
      res.json(results[0]);
    }
  });
});


// Fetch shows available at a theatre
router.get('/theatre/:theatreId', (req, res) => {
  const theatreId = req.params.theatreId;
  const query = 'SELECT * FROM Shows WHERE theatre_id = ?';
  db.query(query, [theatreId], (err, result) => {
    if (err) {
      console.error('Error fetching shows at theatre: ', err);
      res.status(500).json({ error: 'Error fetching shows at theatre' });
      return;
    }
    res.status(200).json(result);
  });
});

// Fetch shows by movie ID for a movie
router.get('/movies/:movieId', (req, res) => {
  const movieId = req.params.movieId;
  const query = 'SELECT * FROM Shows WHERE movie_id = ?';
  db.query(query, [movieId], (err, result) => {
    if (err) {
      console.error('Error fetching shows for movie: ', err);
      res.status(500).json({ error: 'Error fetching shows for movie' });
      return;
    }
    res.status(200).json(result);
  });
});

// Fetch a show by screen ID for a screen
router.get('/screen/:screenId', (req, res) => {
  const screenId = req.params.screenId;
  const query = 'SELECT * FROM Shows WHERE screen_id = ?';
  db.query(query, [screenId], (err, result) => {
    if (err) {
      console.error('Error fetching show for screen: ', err);
      res.status(500).json({ error: 'Error fetching show for screen' });
      return;
    }
    res.status(200).json(result);
  });
});


// Fetch show_date for a show on a screen for a movie in a theatre
router.get('/screens/:screenId/show/:showId/movies/:movieId/theatre/:theatreId', (req, res) => {
  const screenId = req.params.screenId;
  const showId = req.params.showId;
  const movieId = req.params.movieId;
  const theatreId = req.params.theatreId;

  const query = `
    SELECT s.show_date
    FROM Shows s
    INNER JOIN Screen sc ON s.screen_id = sc.screen_id
    WHERE s.screen_id = ? AND s.show_id = ? AND s.movie_id = ? AND s.theatre_id = ?`;

  db.query(query, [screenId, showId, movieId, theatreId], (err, result) => {
    if (err) {
      console.error('Error fetching show details: ' + err.stack);
      res.status(500).json({ error: 'Error fetching show details' });
      return;
    }

    res.json(result);
  });
});


// Fetch show_start_time for a show on a screen for a movie in a theatre
router.get('/screens/:screenId/show/starttime/:showId/movies/:movieId/theatre/:theatreId', (req, res) => {
  const screenId = req.params.screenId;
  const showId = req.params.showId;
  const movieId = req.params.movieId;
  const theatreId = req.params.theatreId;

  const query = `
    SELECT s.start_time as "Time of show"
    FROM Shows s
    INNER JOIN Screen sc ON s.screen_id = sc.screen_id
    WHERE s.screen_id = ? AND s.show_id = ? AND s.movie_id = ? AND s.theatre_id = ?`;

  db.query(query, [screenId, showId, movieId, theatreId], (err, result) => {
    if (err) {
      console.error('Error fetching show details: ' + err.stack);
      res.status(500).json({ error: 'Error fetching show details' });
      return;
    }

    res.json(result);
  });
});


module.exports = router;
