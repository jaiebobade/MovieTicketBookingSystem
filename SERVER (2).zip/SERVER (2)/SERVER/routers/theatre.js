const express = require("express")
const db = require("../db")
const utils = require("../utils")

const router = express.Router()



// GET /theatres - Get all theatres
router.get('/', (req, res) => {
  const query = 'SELECT * FROM Theatre';
  db.query(query, (err, results) => {
    if (err) {
      console.error('Error retrieving theatres: ' + err.stack);
      res.status(500).json({ error: 'Error retrieving theatres' });
      return;
    }
    res.json(results);
  });
});

// GET /theatres/theatreID:id - Get theatre by ID
router.get('/theatreID/:id', (req, res) => {
  const theatreId = req.params.id;
  const query = 'SELECT * FROM Theatre WHERE theatre_id = ?';
  db.query(query, [theatreId], (err, results) => {
    if (err) {
      console.error('Error retrieving theatre: ' + err.stack);
      res.status(500).json({ error: 'Error retrieving theatre' });
      return;
    }
    if (results.length === 0) {
      res.status(404).json({ error: 'Theatre not found' });
    } else {
      res.json(results[0]);
    }
  });
});


// GET /theatres/unique-cities - Get all unique cities from the Theatre table
router.get('/unique-cities', (req, res) => {
  const query = 'SELECT DISTINCT TRIM(city) AS city FROM Theatre';

  db.query(query, (err, results) => {
    if (err) {
      console.error('Error retrieving unique cities: ' + err.stack);
      return res.status(500).json({ error: 'Error retrieving unique cities' });
    }

    console.log('Results:', results); // Log the results to check what data is being returned

    const cities = results.map((result) => result.city);
    res.json(cities);
  });
});


// GET /theatres/cityName/:city - Get theatres for a distinct city
router.get('/cityName/:city', (req, res) => {
  const city = req.params.city;
  const query = 'SELECT * FROM Theatre WHERE city = ?';

  db.query(query, [city], (err, results) => {
    if (err) {
      console.error('Error executing SQL query: ' + err.stack);
      return res.status(500).json({ error: 'Error retrieving theatres' });
    }

    res.json(results);
  });
});







// // POST /theatres - Create a new theatre
// router.post('/', (req, res) => {
//   const { name, address } = req.body;
//   const query = 'INSERT INTO Theatre (name, address) VALUES (?, ?)';
//   const values = [name, address];
//   db.query(query, values, (err, result) => {
//     if (err) {
//       console.error('Error creating theatre: ' + err.stack);
//       res.status(500).json({ error: 'Error creating theatre' });
//       return;
//     }
//     res.json({ message: 'Theatre created successfully' });
//   });
// });



// // Fetch theatres for a specific movie
// router.get('/theatres/movie/:movieId', (req, res) => {
//   const movieId = req.params.movieId;
//   const query = `SELECT DISTINCT Theatre.*
//                  FROM Theatre
//                  INNER JOIN Screen ON Theatre.theatre_id = Screen.theatre_id
//                  INNER JOIN Shows ON Screen.screen_id = Shows.screen_id
//                  WHERE Shows.movie_id = ?`;
//   db.query(query, [movieId], (err, result) => {
//     if (err) {
//       console.error('Error fetching theatres for movie: ', err);
//       res.status(500).json({ error: 'Error fetching theatres for movie' });
//       return;
//     }
//     res.status(200).json(result);
//   });
// });





module.exports = router;


