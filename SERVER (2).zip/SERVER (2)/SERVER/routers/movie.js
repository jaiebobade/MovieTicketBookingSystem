const express = require("express")
const db = require("../db")
const utils = require("../utils")

const router = express.Router()



// GET /movies - Get all movies
router.get('/', (req, res) => {
  console.log("Movies called");
  const query = 'SELECT * FROM Movie';
  db.query(query, (err, results) => {
    if (err) {
      console.error('Error retrieving movies: ' + err.stack);
      res.status(500).json({ error: 'Error retrieving movies' });
      return;
    }
    res.json(results);
  });
});    //done with postman



// GET /movies/:id - Get movie by ID
router.get('/:id', (req, res) => {
  const movieId = req.params.id;
  const query = 'SELECT * FROM Movie WHERE movie_id = ?';
  db.query(query, [movieId], (err, results) => {
    if (err) {
      console.error('Error retrieving movie: ' + err.stack);
      res.status(500).json({ error: 'Error retrieving movie' });
      return;
    }
    if (results.length === 0) {
      res.status(404).json({ error: 'Movie not found' });
    } else {
      res.json(results[0]);
    }
  });
});  // done with postman


// GET /movies/:title - Get movie title by ID
router.get('/:title', (req, res) => {
  const movieId = req.params.id;
  const query = 'SELECT title FROM Movie WHERE movie_id = ?';
  db.query(query, [movieId], (err, results) => {
    if (err) {
      console.error('Error retrieving movie title: ' + err.stack);
      res.status(500).json({ error: 'Error retrieving movie title' });
      return;
    }
    if (results.length === 0) {
      res.status(404).json({ error: 'Movie not found' });
    } else {
      const movieTitle = results[0].title;
      res.json({ title: movieTitle });
    }
  });
});
// PUT /admin/movies/:id - Update movie by ID
router.put('/:id', (req, res) => {
  const id = req.params.id;
  const { title, director, release_date } = req.body;
  const query = 'UPDATE Movie SET title = ?, director = ? , release_date = ? WHERE movie_id = ?';
  const values = [title, director, release_date, id];
  db.query(query, values, (err, result) => {
    if (err) {
      console.error('Error updating movie: ' + err.stack);
      res.status(500).json({ error: 'Error updating movie' });
      return;
    }
    res.json({ message: 'Movie updated successfully' });
  });
});   

// DELETE /admin/movies/:id - Delete movie by ID
router.delete('/:id', (req, res) => {
  const movieId = req.params.id;
  const query = 'DELETE FROM Movie WHERE movie_id = ?';
  db.query(query, [movieId], (err, result) => {
    if (err) {
      console.error('Error deleting movie: ' + err.stack);
      res.status(500).json({ error: 'Error deleting movie' });
      return;
    }
    res.json({ message: 'Movie deleted successfully' });
  });
});
// POST /admin/movies - Create a new movie
router.post('/', (req, res) => {
  const { title, description, release_date, duration, genre, director, cast, poster_url } = req.body;
  const query = 'INSERT INTO Movie (title, description, release_date, duration, genre, director, cast, image) VALUES (?, ?, ?, ?, ?, ?, ?, ?)';
  const values = [title, description, release_date, duration, genre, director, cast, poster_url];
  db.query(query, values, (err, result) => {
    if (err) {
      console.error('Error creating movie: ' + err.stack);
      res.status(500).json({ error: 'Error creating movie' });
      return;
    }
    res.json({ message: 'Movie created successfully' });
  });
}); 

// GET /movies - Get all movies by title
router.get('/api/title', (req, res) => {
  const query = 'SELECT * FROM Movie ORDER BY title';
  db.query(query, (err, results) => {
    if (err) {
      console.error('Error retrieving movies: ' + err.stack);
      res.status(500).json({ error: 'Error retrieving movies' });
      return;
    }
    res.json(results);
  });
});



// GET /movies/:imageUrl - Get movie by image URL
router.get('/by-image-url/:imageUrl', (req, res) => {
  const imageUrl = req.params.imageUrl;
  const query = 'SELECT * FROM Movie WHERE image = ?';

  pool.getConnection((err, connection) => {
    if (err) {
      console.error('Error connecting to the database: ' + err.stack);
      res.status(500).json({ error: 'Error connecting to the database' });
      return;
    }

    connection.query(query, [imageUrl], (err, results) => {
      connection.release(); // Release the connection back to the pool

      if (err) {
        console.error('Error executing SQL query: ' + err.stack);
        res.status(500).json({ error: 'Error retrieving movie' });
        return;
      }

      if (results.length === 0) {
        console.log('Movie not found for image URL: ' + imageUrl);
        res.status(404).json({ error: 'Movie not found' });
      } else {
        const movie = results[0];
        res.json(movie);
      }
    });
  });
});  // done with postman

// GET /api/movies/image/:title - Get movie image URL by title
router.get('/image/:title', (req, res) => {
  const movieTitle = req.params.title;
  const query = 'SELECT image FROM Movie WHERE title = ?';

  db.query(query, [movieTitle], (err, results) => {
    if (err) {
      console.error('Error executing SQL query: ' + err.stack);
      res.status(500).json({ error: 'Error retrieving movie image' });
      return;
    }

    if (results.length === 0) {
      console.log('Movie not found for title: ' + movieTitle);
      res.status(404).json({ error: 'Movie not found' });
    } else {
      const image = results[0].image;
      res.json({ imageUrl: image });
    }
  });
});

// GET /api/movies - Get movie titles and image URLs
router.get('/api/image/title', (req, res) => {
  const query = 'SELECT title, image FROM Movie';

  db.query(query, (err, results) => {
    if (err) {
      console.error('Error executing SQL query: ' + err.stack);
      res.status(500).json({ error: 'Error retrieving movie data' });
      return;
    }

    if (results.length === 0) {
      console.log('No movies found');
      res.status(404).json({ error: 'No movies found' });
    } else {
      res.json(results);
    }
  });
});




module.exports = router