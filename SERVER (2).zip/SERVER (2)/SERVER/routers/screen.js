const express = require("express")
const db = require("../db")
const utils = require("../utils")

const router = express.Router()



// GET /screens - Get all screens
router.get('/', (req, res) => {
  const query = 'SELECT * FROM Screen';
  db.query(query, (err, results) => {
    if (err) {
      console.error('Error retrieving screens: ' + err.stack);
      res.status(500).json({ error: 'Error retrieving screens' });
      return;
    }
    res.json(results);
  });
});

// GET /screens/:id - Get screen by ID
router.get('/:id', (req, res) => {
  const screenId = req.params.id;
  const query = 'SELECT * FROM Screen WHERE screen_id = ?';
  db.query(query, [screenId], (err, results) => {
    if (err) {
      console.error('Error retrieving screen: ' + err.stack);
      res.status(500).json({ error: 'Error retrieving screen' });
      return;
    }
    if (results.length === 0) {
      res.status(404).json({ error: 'Screen not found' });
    } else {
      res.json(results[0]);
    }
  });
});


// Fetch screens for a specific theatre
router.get('/theatre/:theatreId', (req, res) => {
  const theatreId = req.params.theatreId;
  const query = 'SELECT * FROM Screen WHERE theatre_id = ?';

  db.query(query, [theatreId], (err, result) => {
    if (err) {
      console.error('Error fetching screens for theatre: ' + err.stack);
      res.status(500).json({ error: 'Error fetching screens for theatre' });
      return;
    }
    res.json(result);
  });
});



module.exports = router;
